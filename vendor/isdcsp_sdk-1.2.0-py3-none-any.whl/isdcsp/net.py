"""Who is on the other end, by address: this machine or not, which IP, which network to blame.

The platform's request classification (`csp_platform.security.client`) and a service's (`isdcsp.web`) are both built
on these, so "is this request from this machine?" and "which budget does this visitor spend?" have one answer.

- `LOCAL_IP`: what a request from this machine is called where an IP would go. Budgets and bans skip it: nobody
  can lock the owner out of the machine in front of them.
- `ban_key(ip)`: the unit a visitor is counted and banned by -- an IPv4 address, or the /64 of an IPv6 one (one
  host usually controls its whole /64, and must not buy a fresh budget per privacy address).
- `wide_ban_key(ip)`: the IPv6 /48 a /64 ban may escalate to.
- `split_host_header` / `is_loopback_host_header`: the Host header, port and all, `[::1]:8760` included.
"""

from __future__ import annotations

import ipaddress

LOCAL_IP = "local"
LOOPBACK_NAMES = ("127.0.0.1", "localhost", "::1")


def split_host_header(value: str) -> tuple[str, int | None]:
    value = value.strip().lower()
    if value.startswith("["):  # [::1]:8760
        host, _, rest = value[1:].partition("]")
        port = rest[1:] if rest.startswith(":") else ""
    else:
        host, _, port = value.partition(":")
    return host, int(port) if port.isdigit() else None


def is_loopback_host_header(value: str) -> bool:
    host, _ = split_host_header(value)
    return host in LOOPBACK_NAMES


def is_loopback_peer(host: str) -> bool:
    """The TCP peer (`request.client.host`): `localhost` or any loopback address."""
    if host == "localhost":
        return True
    try:
        return ipaddress.ip_address(host).is_loopback
    except ValueError:
        return False


def normalize_ip(value: str) -> str | None:
    try:
        return str(ipaddress.ip_address(value.strip()))
    except ValueError:
        return None


def ban_key(ip: str) -> str:
    """IPv4 bans the address; IPv6 bans the /64 (a single host usually controls the whole /64)."""
    try:
        addr = ipaddress.ip_address(ip)
    except ValueError:
        return ip
    if isinstance(addr, ipaddress.IPv6Address):
        if addr.ipv4_mapped:
            return str(addr.ipv4_mapped)
        return str(ipaddress.IPv6Network(f"{addr}/64", strict=False))
    return str(addr)


def wide_ban_key(ip: str) -> str | None:
    """IPv6 only: the /48 that a /64 ban escalates to after repeated bans inside it."""
    try:
        addr = ipaddress.ip_address(ip)
    except ValueError:
        return None
    if isinstance(addr, ipaddress.IPv6Address) and not addr.ipv4_mapped:
        return str(ipaddress.IPv6Network(f"{addr}/48", strict=False))
    return None

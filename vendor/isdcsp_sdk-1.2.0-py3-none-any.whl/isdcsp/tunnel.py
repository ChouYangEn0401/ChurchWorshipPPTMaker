"""A public address for a local port: cloudflared quick tunnels -- the one implementation (1.2, ADR 0036).

Three layers; use the one you need:

    find_cloudflared / cloudflared_command / answers_from_outside   the pieces
    QuickTunnel(port, command=...)      one cloudflared: `start()` blocks until it has a hostname and a connection;
                                        `alive()`, `stop()`, stderr kept (and logged, capped). The platform's main
                                        address, its share-link door and every share through its gate are this class.
    PublicTunnel(port)                  what a service with its own "open it to outside" button uses: `start()` returns
                                        at once and works in the background (stopped / starting / running / error),
                                        `rotate()` changes the address without a gap, listeners hear every change.

    public_url() / on_url_change(fn)    where this service is reachable from outside right now, whoever opened it:
                                        CSP's gate when CSP runs the service, its own PublicTunnel otherwise.

The recipe: `cloudflared tunnel --no-autoupdate --url http://127.0.0.1:<port> --metrics 127.0.0.1:<random>` inside a
kill-on-close Job Object (`isdcsp.process`) -- a crashed program never leaves a cloudflared behind -- with an
environment without `TUNNEL_*` (cloudflared reads them as options) or `CSP_*` (the platform's own); then poll
`/quicktunnel` for the hostname (fallback: the URL on stderr) and `/ready` until a connection is up. The metrics port
is random per start: a fixed, guessable one would let a DNS-rebinding page read `/quicktunnel`.

Changing the address is four steps, learnt in the 2026-10-07 rehearsal: open the new one, wait until it answers
*from outside* (Cloudflare routes a new name seconds to a minute after cloudflared says ready), switch, close the old
one after a grace period. What only the platform adds on top -- when to change, carrying open pages over with
handover tickets, ending the sessions left on the old address -- stays in the platform.

Standard library only (no httpx): a service that opens a tunnel pays for cloudflared, not for an HTTP stack.
"""

from __future__ import annotations

import json
import logging
import os
import re
import shutil
import socket
import ssl
import subprocess
import threading
import time
import urllib.error
import urllib.request
from collections import deque
from pathlib import Path
from typing import IO, Any, Callable, Iterable

from isdcsp import _env, _http
from isdcsp.process import ManagedProcess

log = logging.getLogger(__name__)

HOSTNAME_RE = re.compile(r"^[a-z0-9]+(?:-[a-z0-9]+)*\.trycloudflare\.com$")
URL_IN_LOG_RE = re.compile(r"https://([a-z0-9]+(?:-[a-z0-9]+)*\.trycloudflare\.com)\b")
LOG_FILE_MAX = 2 * 1024 * 1024
NOT_FOUND = "找不到 cloudflared。請執行 `winget install --id Cloudflare.cloudflared`，或在設定檔填 cloudflared 的路徑。"
QUICK_TUNNEL_API = "api.trycloudflare.com"   # what cloudflared registers with: resolvable whenever quick tunnels work


class TunnelDriverError(Exception):
    """cloudflared is missing, refused to start, or never reported an address. The message is for a person."""


# ---------------------------------------------------------------------------- finding cloudflared
def candidate_paths() -> list[Path]:
    local = os.environ.get("LOCALAPPDATA", "")
    candidates = [
        Path(os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)")) / "cloudflared" / "cloudflared.exe",
        Path(os.environ.get("ProgramFiles", r"C:\Program Files")) / "cloudflared" / "cloudflared.exe",
    ]
    if local:
        candidates.append(Path(local) / "Microsoft" / "WinGet" / "Links" / "cloudflared.exe")
        packages = Path(local) / "Microsoft" / "WinGet" / "Packages"
        if packages.exists():
            candidates.extend(sorted(packages.glob("Cloudflare.cloudflared*/cloudflared*.exe")))
    return candidates


def find_cloudflared(configured: str = "") -> Path | None:
    """The path given (if it exists), else PATH, else the usual install places (Program Files, winget)."""
    if configured:
        path = Path(configured)
        return path if path.is_file() else None
    found = shutil.which("cloudflared")
    if found:
        return Path(found)
    return next((p for p in candidate_paths() if p.is_file()), None)


def conflicting_config_files() -> list[Path]:
    """Quick tunnels refuse to run when ~/.cloudflared/config.yml|yaml exists."""
    home = Path(os.environ.get("USERPROFILE") or Path.home())
    return [p for p in (home / ".cloudflared" / "config.yml", home / ".cloudflared" / "config.yaml") if p.exists()]


def cloudflared_version(exe: Path) -> str | None:
    try:
        result = subprocess.run([str(exe), "--version"], capture_output=True, text=True, timeout=15,
                                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    except (OSError, subprocess.TimeoutExpired):
        return None
    text = (result.stdout or result.stderr).strip()
    match = re.search(r"version\s+(\S+)", text)
    return match.group(1) if match else (text[:60] or None)


def is_quick_tunnel_hostname(value: str | None) -> bool:
    return bool(value) and bool(HOSTNAME_RE.match(value))  # type: ignore[arg-type]


def cloudflared_command(configured_path: str = "", override: list[str] | None = None) -> list[str]:
    """argv prefix for cloudflared; `override` is a test's fake. Refuses setups that break quick tunnels."""
    if override:
        return list(override)
    exe = find_cloudflared(configured_path)
    if exe is None:
        raise TunnelDriverError(NOT_FOUND)
    conflicts = conflicting_config_files()
    if conflicts:
        raise TunnelDriverError(f"發現 {conflicts[0]}：有這個檔案時 quick tunnel 無法啟動，請改名或移走它。")
    return [str(exe)]


def free_port() -> int:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.bind(("127.0.0.1", 0))
        return sock.getsockname()[1]


# ---------------------------------------------------------------------------- asking cloudflared and the edge
_LOCAL = urllib.request.build_opener(urllib.request.ProxyHandler({}))   # loopback only: never a proxy


def query_hostname(base: str, *, timeout: float = 2.0) -> str | None:
    try:
        with _LOCAL.open(f"{base}/quicktunnel", timeout=timeout) as response:
            value = json.loads(response.read() or b"{}").get("hostname")
    except (urllib.error.URLError, OSError, ValueError, AttributeError):
        return None
    return value.lower() if isinstance(value, str) and is_quick_tunnel_hostname(value.lower()) else None


def query_ready(base: str, *, timeout: float = 2.0) -> bool:
    try:
        with _LOCAL.open(f"{base}/ready", timeout=timeout) as response:
            return response.status == 200
    except (urllib.error.URLError, OSError):
        return False


def _edge_status(edge: str, hostname: str, timeout: float) -> int:
    """One HTTPS request to Cloudflare's edge at `edge` (an IPv4 address), naming `hostname` only in TLS SNI and
    `Host`. Returns the status code; the certificate is checked against `hostname`."""
    context = ssl.create_default_context()
    with socket.create_connection((edge, 443), timeout=timeout) as raw:
        with context.wrap_socket(raw, server_hostname=hostname) as tls:
            tls.sendall(f"GET /login HTTP/1.1\r\nHost: {hostname}\r\nUser-Agent: isdcsp\r\n"
                        "Connection: close\r\n\r\n".encode("ascii"))
            head = b""
            while b"\r\n" not in head and len(head) < 256:
                chunk = tls.recv(256)
                if not chunk:
                    break
                head += chunk
    return int(head.split(b"\r\n", 1)[0].split()[1])


def answers_from_outside(hostname: str, *, timeout: float = 5.0) -> bool:
    """Whether https://<hostname> already reaches this machine through Cloudflare.

    cloudflared says ready (`/ready`: a connection to the edge is up) before Cloudflare routes a new quick-tunnel
    hostname: for a few seconds to over a minute the address answers 530 (error 1033) from Cloudflare itself --
    measured on 2026-10-07: 3 s, 18 s, 20 s, more than 60 s. Any answer below 500 came through the tunnel to this
    machine (the platform's public gate answers 421 for a host that is not the address yet, before any ban or rate
    counting, so asking never costs this machine's own IP anything).

    The request goes to an IPv4 address of Cloudflare's edge with the new name only in TLS SNI and `Host`: it never
    asks DNS for the new name. Asked too early, a resolver on this network could cache "no such name" and hand that to
    the owner's phone when its page moves over; and this machine's IPv6 does not reach anywhere.
    """
    if not is_quick_tunnel_hostname(hostname):
        return False
    try:
        edge = socket.getaddrinfo(QUICK_TUNNEL_API, 443, socket.AF_INET, socket.SOCK_STREAM)[0][4][0]
        return _edge_status(edge, hostname, timeout) < 500
    except (OSError, ssl.SSLError, ValueError, IndexError):
        return False


# ---------------------------------------------------------------------------- one cloudflared
def _open_log(log_file: Path) -> IO[str] | None:
    """Open for appending, rotating to `.log.1` first if it is already at the ceiling."""
    try:
        log_file.parent.mkdir(parents=True, exist_ok=True)
        if log_file.exists() and log_file.stat().st_size > LOG_FILE_MAX:
            log_file.replace(log_file.with_suffix(".log.1"))
        return open(log_file, "a", encoding="utf-8")
    except OSError:
        return None


class QuickTunnel:
    def __init__(self, target_port: int, *, command: list[str], protocol: str = "", start_timeout: float = 60,
                 metrics_port: int | None = None, log_file: Path | None = None,
                 lines: deque[str] | None = None, name: str = "cloudflared") -> None:
        self.target_port = target_port
        self.command = list(command)
        self.protocol = protocol
        self.start_timeout = start_timeout
        self.metrics_port = metrics_port
        self.log_file = log_file
        self.lines: deque[str] = lines if lines is not None else deque(maxlen=300)
        self.name = name
        self.hostname: str | None = None
        self._log_hostname: str | None = None
        self._process: ManagedProcess | None = None
        self._returncode: int | None = None

    # ------------------------------------------------------------------ lifecycle
    def start(self) -> str:
        """Start cloudflared; return the new *.trycloudflare.com hostname once a connection is ready."""
        metrics = self.metrics_port or free_port()
        args = [*self.command, "tunnel", "--no-autoupdate", "--url", f"http://127.0.0.1:{self.target_port}",
                "--metrics", f"127.0.0.1:{metrics}"]
        if self.protocol:
            args += ["--protocol", self.protocol]
        env = {k: v for k, v in os.environ.items() if not k.upper().startswith(("TUNNEL_", "CSP_"))}
        try:
            process = ManagedProcess.start(args, env=env, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)
        except OSError as exc:
            raise TunnelDriverError(f"無法啟動 cloudflared：{exc}") from exc
        self._process = process
        threading.Thread(target=self.read_stderr, args=(process.process.stderr,), name=f"{self.name}-stderr",
                         daemon=True).start()
        try:
            self.hostname = self._wait(process, metrics)
        except TunnelDriverError:
            self.stop()
            raise
        return self.hostname

    def _wait(self, process: ManagedProcess, metrics: int) -> str:
        deadline = time.monotonic() + self.start_timeout
        base = f"http://127.0.0.1:{metrics}"
        hostname: str | None = None
        while time.monotonic() < deadline:
            if not process.alive():
                raise TunnelDriverError(f"cloudflared 啟動失敗（exit {process.process.returncode}）")
            hostname = hostname or query_hostname(base) or self._log_hostname
            if hostname is not None and query_ready(base):
                return hostname
            time.sleep(0.3)
        raise TunnelDriverError("等不到 cloudflared 回報網址（逾時）")

    @property
    def pid(self) -> int | None:
        process = self._process
        return process.pid if process is not None and process.alive() else None

    @property
    def returncode(self) -> int | None:
        process = self._process
        return process.process.returncode if process is not None else self._returncode

    def alive(self) -> bool:
        return self._process is not None and self._process.alive()

    def stop(self) -> None:
        process, self._process = self._process, None
        if process is not None:
            process.kill_tree()
            self._returncode = process.process.returncode
            process.close()
        self.hostname = None

    def tail(self, count: int = 3) -> str:
        return " | ".join(list(self.lines)[-count:])

    # ------------------------------------------------------------------ stderr
    def read_stderr(self, stream: Iterable | None) -> None:
        sink = _open_log(self.log_file) if self.log_file else None
        try:
            for raw in stream or ():
                line = (raw.decode("utf-8", "replace") if isinstance(raw, bytes) else raw).rstrip()
                if not line:
                    continue
                self.lines.append(line[:500])
                if sink is not None:
                    sink.write(line + "\n")
                    sink.flush()
                    if sink.tell() > LOG_FILE_MAX:   # checked while writing, not only on open
                        sink.close()
                        sink = _open_log(self.log_file)
                match = URL_IN_LOG_RE.search(line)
                if match and match.group(1) != QUICK_TUNNEL_API:
                    self._log_hostname = match.group(1).lower()
        except (OSError, ValueError):
            pass
        finally:
            if sink is not None:
                sink.close()


# ---------------------------------------------------------------------------- a service's own address
Listener = Callable[[str | None, str | None], Any]      # (old url, new url); None = no address


class PublicTunnel:
    """A service's own public address, for a "open it to outside" button (what PPTMaker's `run_public.bat` does).

    `start()` checks cloudflared synchronously (so a missing install is an error the button can show at once) and
    opens the tunnel in the background; `status()` is what the page polls. If cloudflared dies, the state turns to
    "error" and `on_stop` runs -- the service's chance to end the sessions that came in through it. `rotate()` is the
    four-step change described in the module docstring; the old address keeps working for `grace_seconds`, and
    `hosts()` (what a Host check should accept) includes it until then.
    """

    def __init__(self, port: int, *, cloudflared_path: str | Callable[[], str] = "", command: list[str] | None = None,
                 log_file: Path | None = None, protocol: str = "", start_timeout: float = 60,
                 on_stop: Callable[[], Any] | None = None, answers: Callable[[str], bool] = answers_from_outside,
                 grace_seconds: float = 300, public_wait_seconds: float = 180, watch_seconds: float = 2.0) -> None:
        self.port = port
        self._path = cloudflared_path if callable(cloudflared_path) else (lambda: cloudflared_path)
        self._command = command
        self.log_file = log_file
        self.protocol = protocol
        self.start_timeout = start_timeout
        self.on_stop = on_stop
        self._answers = answers
        self.grace_seconds = grace_seconds
        self.public_wait_seconds = public_wait_seconds
        self.watch_seconds = watch_seconds
        self._lock = threading.RLock()
        self._runtime: QuickTunnel | None = None
        self._old: tuple[QuickTunnel, str, float] | None = None     # the address being replaced, until when
        self._generation = 0
        self.state = "stopped"
        self.hostname: str | None = None
        self.error = ""
        self.started_at: float | None = None
        self._listeners: list[Listener] = []

    # ------------------------------------------------------------------ what a page shows
    @property
    def url(self) -> str | None:
        return f"https://{self.hostname}" if self.hostname else None

    def installed(self) -> bool:
        return bool(self._command or find_cloudflared(self._path()))

    def status(self) -> dict:
        with self._lock:
            return {"state": self.state, "url": self.url if self.state == "running" else None, "error": self.error,
                    "startedAt": self.started_at, "installed": self.installed()}

    def current_host(self) -> str | None:
        """The address a Host check should accept now (None when closed)."""
        with self._lock:
            return self.hostname if self.state in ("starting", "running") else None

    def hosts(self) -> set[str]:
        """Every address that still works: the current one, and the one being replaced during the grace period."""
        with self._lock:
            out = {self.hostname} if self.hostname and self.state in ("starting", "running") else set()
            if self._old is not None and self._old[2] > time.monotonic():
                out.add(self._old[1])
            return out

    def add_listener(self, listener: Listener) -> None:
        self._listeners.append(listener)

    # ------------------------------------------------------------------ open / close
    UNDER_CSP = ("CSP 正在管這個服務：對外要用平台的分享（服務頁的「開到外面」），不能自己開通道——"
                 "平台看不到、也關不掉自己開的通道。")

    def start(self) -> dict:
        """Open in the background; raises `TunnelDriverError` at once when cloudflared cannot run at all, or when CSP
        runs this service (the red line "no tunnel of its own": the platform's gate is the way out, ADR 0036)."""
        if _env.in_platform():
            raise TunnelDriverError(self.UNDER_CSP)
        with self._lock:
            if self.state in ("starting", "running"):
                return self.status()
            command = cloudflared_command(self._path(), self._command)
            self._generation += 1
            generation = self._generation
            self.state, self.hostname, self.error, self.started_at = "starting", None, "", time.time()
        threading.Thread(target=self._open, args=(command, generation), name="isdcsp-tunnel", daemon=True).start()
        return self.status()

    def _new_runtime(self, command: list[str]) -> QuickTunnel:
        return QuickTunnel(self.port, command=command, protocol=self.protocol, start_timeout=self.start_timeout,
                           log_file=self.log_file, name="isdcsp-cloudflared")

    def _open(self, command: list[str], generation: int) -> None:
        runtime = self._new_runtime(command)
        try:
            hostname = runtime.start()
        except TunnelDriverError as exc:
            with self._lock:
                if generation == self._generation:
                    self.state, self.error = "error", str(exc)
            return
        with self._lock:
            if generation != self._generation:          # stopped while it was opening
                runtime.stop()
                return
            self._runtime, self.hostname, self.state = runtime, hostname, "running"
        _set_active(self)
        self._tell(None, self.url)
        threading.Thread(target=self._watch, args=(generation,), name="isdcsp-tunnel-watch", daemon=True).start()

    def _watch(self, generation: int) -> None:
        while True:
            time.sleep(self.watch_seconds)
            with self._lock:
                if generation != self._generation or self.state != "running":
                    return
                runtime = self._runtime
                self._drop_old_if_due()
            if runtime is not None and not runtime.alive():
                with self._lock:
                    if generation != self._generation:
                        return
                    old = self.url
                    self.state, self.hostname, self._runtime = "error", None, None
                    self.error = "對外連結中斷了（cloudflared 停止執行），請再開一次。"
                self._tell(old, None)
                if self.on_stop is not None:
                    self.on_stop()
                return

    def stop(self, reason: str = "") -> dict:
        with self._lock:
            self._generation += 1
            runtime, self._runtime = self._runtime, None
            old_runtime = self._old[0] if self._old else None
            self._old = None
            old = self.url
            self.state, self.hostname, self.started_at, self.error = "stopped", None, None, reason
        for each in (runtime, old_runtime):
            if each is not None:
                each.stop()
        if old:
            self._tell(old, None)
        if self.on_stop is not None:
            self.on_stop()
        return self.status()

    def wait_until_ready(self, timeout: float = 60) -> dict:
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline and self.state == "starting":
            time.sleep(0.2)
        return self.status()

    # ------------------------------------------------------------------ change the address without a gap
    def rotate(self) -> bool:
        """Open a new address, wait until it answers from outside, switch, keep the old one `grace_seconds`.
        Blocks (run it in a thread). False when the new one never came up -- the old address simply stays."""
        with self._lock:
            if self.state != "running" or self._runtime is None:
                return False
            command = cloudflared_command(self._path(), self._command)
            generation = self._generation
        runtime = self._new_runtime(command)
        try:
            hostname = runtime.start()
        except TunnelDriverError as exc:
            log.warning("new address did not open: %s", exc)
            return False
        deadline = time.monotonic() + self.public_wait_seconds
        while not self._answers(hostname):
            if time.monotonic() > deadline or generation != self._generation:
                runtime.stop()
                return False
            time.sleep(2.0)
        with self._lock:
            if generation != self._generation or self._runtime is None:
                runtime.stop()
                return False
            if self._old is not None:
                self._old[0].stop()
            old_url = self.url
            self._old = (self._runtime, self.hostname or "", time.monotonic() + self.grace_seconds)
            self._runtime, self.hostname, self.started_at = runtime, hostname, time.time()
        self._tell(old_url, self.url)
        return True

    def _drop_old_if_due(self) -> None:
        if self._old is not None and self._old[2] <= time.monotonic():
            self._old[0].stop()
            self._old = None

    def _tell(self, old: str | None, new: str | None) -> None:
        for listener in [*self._listeners, *_listeners]:
            try:
                listener(old, new)
            except Exception:                  # a listener must never break the tunnel
                log.exception("url listener failed")


# ---------------------------------------------------------------------------- where am I reachable
_active: PublicTunnel | None = None
_listeners: list[Listener] = []
_watcher: threading.Thread | None = None
_state_lock = threading.Lock()
WATCH_SECONDS = 15.0


def _set_active(tunnel: PublicTunnel) -> None:
    global _active
    _active = tunnel


def public_url() -> str | None:
    """Where this service is reachable from outside now: its share on CSP's gate when CSP runs it (asked from the
    platform), else the address of its own running `PublicTunnel`; None when it is not reachable from outside."""
    if _env.in_platform():
        service_id = _env.service_id()
        if not service_id:
            return None
        try:
            return (_http.request("GET", f"/services/{service_id}") or {}).get("public_url")
        except _http.PlatformError:
            return None
    tunnel = _active
    return tunnel.url if tunnel is not None and tunnel.state == "running" else None


def on_url_change(listener: Listener) -> None:
    """Call `listener(old_url, new_url)` whenever `public_url()` changes -- to register a webhook again, to post the
    new link. Its own tunnel tells at once; under CSP the platform is asked every `WATCH_SECONDS` (one small local
    request; the thread starts with the first listener)."""
    global _watcher
    with _state_lock:
        _listeners.append(listener)
        if _env.in_platform() and _watcher is None:
            _watcher = threading.Thread(target=_watch_platform, name="isdcsp-url-watch", daemon=True)
            _watcher.start()


def _watch_platform() -> None:
    last = public_url()
    while True:
        time.sleep(WATCH_SECONDS)
        now = public_url()
        if now != last:
            for listener in list(_listeners):
                try:
                    listener(last, now)
                except Exception:
                    log.exception("url listener failed")
            last = now

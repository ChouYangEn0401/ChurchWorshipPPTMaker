"""Opaque random tokens. A cookie (or a form, or a link) carries the token; storage keeps only its SHA-256.

The platform's sessions, devices, handover tickets and one-time links, and a service's sessions (`isdcsp.web`) and
login codes (`isdcsp.codes`), all use these -- so "a token is 32+ url-safe characters and only its digest is kept"
is one rule, not one per module.
"""

from __future__ import annotations

import hashlib
import hmac
import re
import secrets
import threading
from typing import Any

_TOKEN_RE = re.compile(r"^[A-Za-z0-9_-]{32,128}$")


def new_token(nbytes: int = 32) -> str:
    return secrets.token_urlsafe(nbytes)


def token_digest(token: str) -> str:
    return hashlib.sha256(token.encode("ascii", "ignore")).hexdigest()


def looks_like_token(value: str | None) -> bool:
    return bool(value) and bool(_TOKEN_RE.match(value))


def same(a: str | None, b: str | None) -> bool:
    """Constant-time equality for secrets; an empty side is never equal."""
    if not a or not b:
        return False
    return hmac.compare_digest(a.encode("utf-8"), b.encode("utf-8"))


class OneTimeCodes:
    """Short-lived, single-use codes kept in memory (digests only). A restart voids them all.

    The platform uses it for the local sign-in link `python main.py` opens (C1): minted only with the admin token,
    redeemed once, only on this machine.
    """

    def __init__(self, clock: Any, ttl_seconds: int = 120) -> None:
        self.clock = clock
        self.ttl = ttl_seconds
        self._codes: dict[str, float] = {}
        self._lock = threading.Lock()

    def create(self) -> str:
        code = new_token(24)
        now = self.clock.now()
        with self._lock:
            self._codes = {k: v for k, v in self._codes.items() if v > now}
            self._codes[token_digest(code)] = now + self.ttl
        return code

    def redeem(self, code: str | None) -> bool:
        if not code or len(code) > 200:
            return False
        with self._lock:
            expiry = self._codes.pop(token_digest(code), None)
        return expiry is not None and expiry >= self.clock.now()

"""A tiny JSON client for the platform's Control API v1 -- standard library only (no requests/httpx needed).

Every call carries the service's own token (`CSP_SERVICE_TOKEN`); the platform only lets a service do what its
approved `[uses]` says. Tests replace `request` / `request_bytes` to avoid a network.
"""

from __future__ import annotations

import json
import urllib.error
import urllib.parse
import urllib.request
from typing import Any

from isdcsp import _env

TIMEOUT = 10
UPLOAD_TIMEOUT = 120


class PlatformError(Exception):
    def __init__(self, status: int, message: str, code: str = "") -> None:
        super().__init__(message)
        self.status, self.code = status, code


def request(method: str, path: str, body: Any = None) -> Any:
    data = json.dumps(body).encode("utf-8") if body is not None else None
    return _send(method, path, data, {"Content-Type": "application/json"} if data is not None else {}, TIMEOUT)


def request_bytes(method: str, path: str, data: bytes, *, params: dict[str, str] | None = None) -> Any:
    """Raw bytes as the body (a report for the information station); the answer is JSON like everything else."""
    query = ("?" + urllib.parse.urlencode(params)) if params else ""
    return _send(method, path + query, data, {"Content-Type": "application/octet-stream"}, UPLOAD_TIMEOUT)


def _send(method: str, path: str, data: bytes | None, headers: dict[str, str], timeout: float) -> Any:
    base = _env.api_url()
    if not base:
        raise PlatformError(0, "不在平台裡（沒有 CSP_API）", "local_mode")
    req = urllib.request.Request(f"{base}{path}", data=data, method=method, headers={
        "Authorization": f"Bearer {_env.service_token()}", "Accept": "application/json", **headers})
    # Loopback only: never through a proxy from the environment.
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
    try:
        with opener.open(req, timeout=timeout) as response:
            raw = response.read()
            return json.loads(raw) if raw else None
    except urllib.error.HTTPError as exc:
        try:
            detail = json.loads(exc.read() or b"{}")
        except ValueError:
            detail = {}
        raise PlatformError(exc.code, detail.get("error") or str(exc), detail.get("code", "")) from exc
    except (urllib.error.URLError, OSError) as exc:
        raise PlatformError(0, f"連不到平台：{exc}", "unreachable") from exc

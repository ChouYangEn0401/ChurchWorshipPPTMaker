"""`python -m isdcsp check [folder]`: the red-line list, before the platform ever sees the project (BLUEPRINT §4.4).

**The rules are defined here**, in the upper layer, because "what a service must never do" is part of the
contract rather than something the platform decides on the side. `csp_platform.kernel.admission` imports
`RULES` and `scan` from this module, so `csp svc add` and `csp try` run *this* list -- a project that passes
here passes there, by construction rather than by two lists being kept in step.

Exit code: 0 no blockers, 1 at least one ✗ (block). Findings name the file and the line; a person decides.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path

SKIP_DIRS = {".git", ".venv", "venv", "env", "node_modules", "__pycache__", ".mypy_cache", ".pytest_cache",
             "dist", "build", ".idea", ".vscode", "legacy", "site-packages"}
SCAN_SUFFIXES = {".py", ".bat", ".cmd", ".ps1", ".toml", ".json", ".yaml", ".yml", ".cfg", ".ini"}
MAX_FILES = 4000
MAX_FILE_BYTES = 512 * 1024


@dataclass(frozen=True)
class Finding:
    rule: str
    severity: str        # "block" (✗) | "warn" (!) | "info" (-)
    message: str
    file: str = ""
    line: int = 0

    def public(self) -> dict:
        return {"rule": self.rule, "severity": self.severity, "message": self.message, "file": self.file,
                "line": self.line}


@dataclass(frozen=True)
class Rule:
    id: str
    severity: str
    pattern: re.Pattern
    message: str
    suffixes: frozenset[str] = frozenset(SCAN_SUFFIXES)


_Rule = Rule          # the private name this module used before the platform imported it


RULES: tuple[Rule, ...] = (
    _Rule("bind-all-interfaces", "block",
          re.compile(r"""(host\s*=\s*['"]0\.0\.0\.0['"]|--host[ =]+0\.0\.0\.0|['"]0\.0\.0\.0['"]\s*,\s*\d{2,5})"""),
          "綁 0.0.0.0：同網路的人不經門口就能連；只綁 127.0.0.1"),
    _Rule("debug-server", "block",
          re.compile(r"""(\.run\([^)]*debug\s*=\s*True|DEBUG\s*=\s*True\b|use_debugger\s*=\s*True)"""),
          "debug 模式：Werkzeug debugger 等於讓人遠端執行程式", frozenset({".py"})),
    _Rule("dev-reload", "warn",
          re.compile(r"""(reload\s*=\s*True|--reload\b|RELOAD['"]\s*,\s*['"](1|true|on)['"])""", re.IGNORECASE),
          "開著 reload：開發用的模式，而且會開 SO_REUSEADDR（可能安靜共用別人的埠）", frozenset({".py"})),
    _Rule("shell-true", "block", re.compile(r"""shell\s*=\s*True"""),
          "shell=True：參數裡一個引號就能多跑一個指令；改用字串陣列", frozenset({".py"})),
    _Rule("os-system", "warn", re.compile(r"""\bos\.(system|popen)\("""),
          "os.system／os.popen 走 shell；改用字串陣列的 subprocess", frozenset({".py"})),
    _Rule("other-project-secrets", "warn",
          re.compile(r"""(MyFirstTelegramClawBot|cloudeservice_secrets|admin\.token|stepup_totp)"""),
          "讀別的專案的設定或金鑰：一個服務被挾持就拿走全部；改用平台的機密"),
    _Rule("direct-telegram", "warn", re.compile(r"""api\.telegram\.org"""),
          "自己打 Telegram：之後改用 csp.notify，token 只留在平台"),
    _Rule("own-tunnel", "warn", re.compile(r"""\bcloudflared\b.*\btunnel\b|trycloudflare"""),
          "自己開 cloudflared：平台看不到、關不掉；改由平台開"),
    _Rule("reuse-address", "warn", re.compile(r"""(allow_reuse_address\s*=\s*True|SO_REUSEADDR)"""),
          "Windows 上的 SO_REUSEADDR 會讓兩個程式安靜共用同一個埠（見 docs/PORTS.md）", frozenset({".py"})),
)


def scan(folder: Path, *, rules: tuple[Rule, ...] = RULES, require_manifest: bool = True) -> list[Finding]:
    """Run the red lines over a project's source files: tests, virtualenvs and vendored folders are skipped.

    `require_manifest=False` leaves out the "no `service.isdcsp.toml`" warning -- the platform already knows
    the manifest (it is how the service got registered), so only this CLI asks for it.
    """
    folder = Path(folder)
    findings: list[Finding] = []
    count = 0
    for path in sorted(folder.rglob("*")):
        if count >= MAX_FILES:
            findings.append(Finding("scan-limit", "info", f"檔案太多，只掃了前 {MAX_FILES} 個"))
            break
        rel = path.relative_to(folder)
        if any(part in SKIP_DIRS or part.startswith(".") and part not in (".", "..") for part in rel.parts[:-1]):
            continue
        if not path.is_file() or path.suffix.lower() not in SCAN_SUFFIXES:
            continue
        if rel.parts and rel.parts[0] in ("tests", "test"):
            continue
        try:
            if path.stat().st_size > MAX_FILE_BYTES:
                continue
            text = path.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
        count += 1
        suffix = path.suffix.lower()
        for number, line in enumerate(text.splitlines(), start=1):
            stripped = line.strip()
            if stripped.startswith(("#", "rem ", "REM ", "::", "//")):
                continue
            for rule in rules:
                if suffix in rule.suffixes and rule.pattern.search(line):
                    findings.append(Finding(rule.id, rule.severity, rule.message, str(rel), number))
    if require_manifest and not (folder / "service.isdcsp.toml").is_file() \
            and not (folder / "csp-service.toml").is_file():
        findings.append(Finding("no-manifest", "warn", "沒有 service.isdcsp.toml：平台不知道怎麼啟動、開給誰"))
    return findings


def report(findings: list[Finding]) -> str:
    marks = {"block": "✗", "warn": "!", "info": "-"}
    if not findings:
        return "✓ 沒有發現紅線"
    lines = [f"{marks.get(f.severity, '-')} {f.message}" + (f"（{f.file}:{f.line}）" if f.file else "")
             for f in findings]
    blockers = sum(1 for f in findings if f.severity == "block")
    lines.append(f"{'✗' if blockers else '✓'} {blockers} 個不能上架的問題、{len(findings) - blockers} 個提醒")
    return "\n".join(lines)

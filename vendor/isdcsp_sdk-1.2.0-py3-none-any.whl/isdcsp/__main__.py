"""`python -m isdcsp <command>`

    check [folder]                     the red-line list (exit 1 when something blocks)
    new <folder> --id my-tool [--name] [--login platform|own]
                                       a new project from a template (refuses a non-empty folder):
                                       platform = identity from CSP's gate (L2); own = its own team password
    info                               where am I: platform or local mode, port, service id
"""

from __future__ import annotations

import argparse
import re
import sys
from importlib import resources
from pathlib import Path

from isdcsp import _env
from isdcsp.check import report, scan

ID_RE = re.compile(r"^[a-z0-9][a-z0-9_-]{1,40}$")
RENAMES = {"gitignore": ".gitignore"}   # a dot-file inside a package is easy to lose; it is renamed on copy
TEMPLATES = {"platform": "web", "own": "web-own"}   # --login: who checks who the visitor is


def _sdk_source() -> str:
    """How the new project installs this SDK: the source folder when it is an editable checkout."""
    here = Path(__file__).resolve().parents[2]          # sdk/src/isdcsp/__main__.py -> sdk/
    if (here / "pyproject.toml").is_file():
        return "-e " + here.as_posix()
    return "isdcsp-sdk"


def _out(text: str) -> None:
    sys.stdout.buffer.write((text + "\n").encode("utf-8"))   # works on a cp950 console too
    sys.stdout.flush()


def cmd_check(args: argparse.Namespace) -> int:
    findings = scan(Path(args.folder))
    _out(report(findings))
    return 1 if any(f.severity == "block" for f in findings) else 0


def cmd_new(args: argparse.Namespace) -> int:
    folder = Path(args.folder).resolve()
    if not ID_RE.match(args.id):
        _out("✗ --id 只能是小寫英數字、_、-（2–41 字）")
        return 2
    if folder.exists() and any(folder.iterdir()):
        _out(f"✗ {folder} 不是空的：不會蓋掉任何東西")
        return 1
    template = resources.files("isdcsp") / "templates" / TEMPLATES[args.login]
    values = {"{{id}}": args.id, "{{name}}": args.name or args.id, "{{sdk}}": _sdk_source()}
    written = []

    def copy(node, target: Path) -> None:
        for child in node.iterdir():
            name = RENAMES.get(child.name.removesuffix(".tmpl"), child.name.removesuffix(".tmpl"))
            if child.is_dir():
                copy(child, target / name)
                continue
            text = child.read_text(encoding="utf-8")
            for key, value in values.items():
                text = text.replace(key, value)
            (target / name).parent.mkdir(parents=True, exist_ok=True)
            (target / name).write_text(text, encoding="utf-8")
            written.append(str((target / name).relative_to(folder)))

    copy(template, folder)
    _out(f"✓ 建好了 {folder}（{len(written)} 個檔案）")
    _out("接下來：")
    _out(f"  cd {folder}")
    _out("  python -m venv .venv ; .venv\\Scripts\\pip install -r requirements.txt")
    if args.login == "own":
        _out("  .venv\\Scripts\\python app.py set-password   # 團隊密碼")
    _out("  .venv\\Scripts\\python app.py            # 自己先跑跑看：http://127.0.0.1:8800")
    _out(f"  csp svc add . ; csp svc approve {args.id} ; csp svc start {args.id}")
    return 0


def cmd_info(args: argparse.Namespace) -> int:
    _out(f"模式：{'平台（CSP 啟動的）' if _env.in_platform() else '本機（沒有平台）'}")
    _out(f"服務：{_env.service_id() or '（沒有 service.isdcsp.toml）'}  埠：{_env.port()}  登入方式：{_env.auth_mode()}")
    _out(f"專案資料夾：{_env.project_root()}")
    return 0


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="python -m isdcsp", description="isdcsp SDK 的小工具")
    sub = parser.add_subparsers(dest="command", required=True)
    p = sub.add_parser("check", help="掃紅線（有 ✗ 就不能上架）")
    p.add_argument("folder", nargs="?", default=".")
    p.set_defaults(func=cmd_check)
    p = sub.add_parser("new", help="從範本建一個新專案（紅線全過）")
    p.add_argument("folder")
    p.add_argument("--id", required=True)
    p.add_argument("--name", default="")
    p.add_argument("--login", choices=sorted(TEMPLATES), default="platform",
                   help="platform：身分交給平台（預設）；own：自己的團隊密碼（isdcsp.web）")
    p.set_defaults(func=cmd_new)
    p = sub.add_parser("info", help="現在是平台模式還是本機模式、埠、服務 id")
    p.set_defaults(func=cmd_info)
    args = parser.parse_args(argv)
    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())

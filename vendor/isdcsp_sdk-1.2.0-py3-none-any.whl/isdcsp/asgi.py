"""The guardrail around an ASGI app (FastAPI, Starlette, ...): `Guard(app)` and `serve(app)` (BLUEPRINT §4.4).

`Guard` answers "who is asking" for every request (`identity.identify`) before the app sees it, and refuses what
should never get in: a peer that is not this machine, a Host that is not local (DNS rebinding), a request through
the gate without the platform's signed identity (for `auth = "platform"`), and a state-changing request -- or a
WebSocket -- sent by another website (Origin does not match). The last one also protects the owner's local
requests, which would otherwise be open to any page in the owner's own browser: a WebSocket handshake is a GET,
so without its own check any website could open one to `ws://127.0.0.1:<port>` and be taken for the owner.

The principal is put where handlers can read it: `isdcsp.principal(request)` (Starlette: `request.state`).
Responses get `X-Content-Type-Options: nosniff`, `Referrer-Policy: same-origin` and `X-Frame-Options:
SAMEORIGIN` unless the app set its own.

`serve(app)` runs uvicorn on 127.0.0.1 only, on `isdcsp.port()`, with proxy headers off and no reload.
"""

from __future__ import annotations

from typing import Any
from urllib.parse import urlsplit

from isdcsp import _env
from isdcsp.identity import PlatformKeys, Principal, Refused, identify

UNSAFE = {"POST", "PUT", "PATCH", "DELETE"}
STATE_KEY = "isdcsp_principal"
_HEADERS = ((b"x-content-type-options", b"nosniff"), (b"referrer-policy", b"same-origin"),
            (b"x-frame-options", b"SAMEORIGIN"))


def _headers(scope: dict) -> dict[str, str]:
    return {k.decode("latin-1").lower(): v.decode("latin-1") for k, v in scope.get("headers", [])}


def _cross_site(method: str, headers: dict[str, str], *, websocket: bool = False) -> bool:
    """A state-changing request (or any WebSocket) whose Origin is another site. No Origin (curl,
    server-to-server) passes; browsers always send one on these."""
    if method not in UNSAFE and not websocket:
        return False
    origin = headers.get("origin")
    if not origin:
        return False
    if origin == "null":
        return True
    expected = (headers.get("x-forwarded-host") or headers.get("host") or "").lower()
    return urlsplit(origin).netloc.lower() != expected


class Guard:
    def __init__(self, app: Any, *, auth: str | None = None, service_id: str | None = None,
                 keys: PlatformKeys | None = None) -> None:
        self.app = app
        self.auth = auth
        self.service_id = service_id
        self.keys = keys

    async def __call__(self, scope: dict, receive: Any, send: Any) -> None:
        if scope["type"] not in ("http", "websocket"):
            await self.app(scope, receive, send)
            return
        headers = _headers(scope)
        client = (scope.get("client") or ("", 0))[0]
        try:
            who = identify(headers, client, auth=self.auth, service_id=self.service_id, keys=self.keys)
            if _cross_site(scope.get("method", "GET"), headers, websocket=scope["type"] == "websocket"):
                raise Refused(403, "別的網站送來的修改請求（CSRF）")
        except Refused as exc:
            await self._refuse(scope, send, exc)
            return
        scope.setdefault("state", {})[STATE_KEY] = who
        if scope["type"] == "websocket":
            await self.app(scope, receive, send)
            return

        async def send_with_headers(message: dict) -> None:
            if message["type"] == "http.response.start":
                present = {k.lower() for k, _ in message.get("headers", [])}
                message = dict(message, headers=list(message.get("headers", [])) +
                               [(k, v) for k, v in _HEADERS if k not in present])
            await send(message)

        await self.app(scope, receive, send_with_headers)

    @staticmethod
    async def _refuse(scope: dict, send: Any, exc: Refused) -> None:
        if scope["type"] == "websocket":
            await send({"type": "websocket.close", "code": 1008})
            return
        body = f"{exc.status} {exc.reason}".encode("utf-8")
        await send({"type": "http.response.start", "status": exc.status,
                    "headers": [(b"content-type", b"text/plain; charset=utf-8"),
                                (b"content-length", str(len(body)).encode()), *_HEADERS]})
        await send({"type": "http.response.body", "body": body})


def principal(request_or_scope: Any) -> Principal | None:
    """The principal `Guard` attached: pass a Starlette/FastAPI `Request` or an ASGI scope."""
    state = getattr(request_or_scope, "state", None)
    if state is not None and not isinstance(request_or_scope, dict):
        return getattr(state, STATE_KEY, None)
    if isinstance(request_or_scope, dict):
        return request_or_scope.get("state", {}).get(STATE_KEY)
    return None


def serve(app: Any, *, port: int | None = None, guard: bool = True, log_level: str = "info") -> None:
    """Run `app` on 127.0.0.1 (never 0.0.0.0) on the platform's port; wrapped in `Guard` unless told not to."""
    import uvicorn

    target = Guard(app) if guard and not isinstance(app, Guard) else app
    uvicorn.run(target, host="127.0.0.1", port=port or _env.port(), proxy_headers=False, forwarded_allow_ips="",
                server_header=False, log_level=log_level, reload=False)

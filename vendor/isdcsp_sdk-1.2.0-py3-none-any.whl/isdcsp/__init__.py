"""isdcsp -- the upper layer of this machine's CloudServicesPlatform: the contract every service (and the platform
itself) is built on, and the one implementation of the parts they share (BLUEPRINT §4.3–4.5, ADR 0032).

    import isdcsp

    isdcsp.port()                 # the port to listen on (CSP's, or the manifest's in local mode)
    isdcsp.serve(app)             # uvicorn on 127.0.0.1 only, wrapped in the guard below
    isdcsp.Guard(app)             # who is asking (signed identity through the gate / the owner here), Host, CSRF
    isdcsp.principal(request)     # -> Principal(kind="owner"|"member"|"anonymous", name, groups, via)
    isdcsp.notify("報表好了")       # Telegram to the owner through CSP (printed in local mode)
    isdcsp.secret("SHEET_API_KEY")  # a secret this service declared in [uses]
    isdcsp.run(["git", "status"])  # never a shell string
    isdcsp.data_dir("cache")      # <project>/data/cache
    isdcsp.artifacts.put("out/today.html", category="daily")   # a report onto the information station (1.1)
    isdcsp.totp.for_service().verify("123456")                 # an authenticator code (1.2)
    isdcsp.codes.for_service().request(visitor_ip)             # a one-time login code to a phone (1.2)

Never imports the platform: a project depends on this package, not on CloudServicesPlatform. Works without the
platform (local mode). `python -m isdcsp check` runs the red-line list; `python -m isdcsp new` starts a project.

The modules a service may not need (`totp`, `codes`, `throttle`, ...) load on first use, not on `import isdcsp`: a service
pays for what it uses.
"""

from __future__ import annotations

import importlib
from typing import Any

from isdcsp import artifacts
from isdcsp._env import in_platform, port, project_root, service_id
from isdcsp.asgi import Guard, principal, serve
from isdcsp.identity import IdentityError, Principal, Refused, identify, verify_assertion
from isdcsp.tools import data_dir, notify, run, secret

__version__ = "1.2.0"   # 1.x follows the platform's /api/v1 (1.1: artifacts.put; 1.2: totp, codes, throttle, net, tokens)

_LAZY = ("check", "codes", "net", "passwords", "process", "spa", "throttle", "tokens", "totp", "tunnel", "web")

__all__ = ["Guard", "IdentityError", "Principal", "Refused", "artifacts", "data_dir", "identify", "in_platform",
           "notify", "port", "principal", "project_root", "run", "secret", "serve", "service_id", "verify_assertion",
           *_LAZY]


def __getattr__(name: str) -> Any:
    if name in _LAZY:
        module = importlib.import_module(f"isdcsp.{name}")
        globals()[name] = module
        return module
    raise AttributeError(f"module 'isdcsp' has no attribute {name!r}")

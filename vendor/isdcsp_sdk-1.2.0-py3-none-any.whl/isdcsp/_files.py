"""Files that hold secrets: created once, readable only by the current user, never half-written.

The platform keeps its own key files with these (`csp_platform.core.keystore` imports them), and a service keeps
its local-mode secrets with them (`isdcsp.totp`'s own authenticator secret, under `<project>/data/secrets/`).

- `restrict_to_current_user(path)`: Windows -- drop inherited ACEs, grant the current user only (`icacls`); for a
  folder the grant is inheritable, so files created inside it later are private from their first byte.
  Elsewhere `chmod 600` / `700`. Best effort: it returns False instead of raising, and the caller decides.
- `private_dir(path)`: a folder for secrets, created and restricted once per process.
- `create_exclusive(path, data)`: write a file that must not exist yet (O_EXCL), then restrict it.
- `atomic_write_bytes(path, data)`: replace a file so a crash leaves the old one or the new one, never a torn one
  (a sibling temp file, flushed and fsynced, then `os.replace`). On Windows a replaced file carries the *temp*
  file's ACL, not the old one's -- which is why secrets live in a `private_dir`, whose ACL the temp file inherits.
"""

from __future__ import annotations

import logging
import os
import subprocess
import sys
import tempfile
import threading
from pathlib import Path

log = logging.getLogger(__name__)

_restricted: set[str] = set()
_restricted_lock = threading.Lock()


def restrict_to_current_user(path: Path) -> bool:
    """Best-effort: remove inherited ACEs and grant full control to the current user only."""
    folder = path.is_dir()
    if sys.platform != "win32":
        try:
            os.chmod(path, 0o700 if folder else 0o600)
            return True
        except OSError:
            return False
    user = os.environ.get("USERNAME")
    if not user:
        return False
    domain = os.environ.get("USERDOMAIN")
    principal = f"{domain}\\{user}" if domain else user
    grant = f"{principal}:(OI)(CI)F" if folder else f"{principal}:F"
    try:
        result = subprocess.run(
            ["icacls", str(path), "/inheritance:r", "/grant:r", grant],
            capture_output=True, timeout=15, creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
        )
    except (OSError, subprocess.TimeoutExpired):
        return False
    if result.returncode != 0:
        log.warning("icacls failed for %s (exit %s)", path.name, result.returncode)
    return result.returncode == 0


def private_dir(path: Path) -> Path:
    """`path`, created if needed and restricted to the current user (once per process, not on every write)."""
    path.mkdir(parents=True, exist_ok=True)
    key = str(path.resolve())
    with _restricted_lock:
        if key not in _restricted:
            restrict_to_current_user(path)
            _restricted.add(key)
    return path


def create_exclusive(path: Path, data: bytes) -> None:
    """Create `path` with `data`; raises FileExistsError if it is already there (it is never overwritten)."""
    path.parent.mkdir(parents=True, exist_ok=True)
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, "O_BINARY", 0), 0o600)
    with os.fdopen(fd, "wb") as fh:
        fh.write(data)
    restrict_to_current_user(path)


def atomic_write_bytes(path: Path, data: bytes) -> None:
    """Replace `path` with `data` in one step: readers see the old content or the new, never part of either."""
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temp = tempfile.mkstemp(prefix=f".{path.name}.", suffix=".tmp", dir=path.parent)
    try:
        with os.fdopen(fd, "wb") as fh:
            fh.write(data)
            fh.flush()
            os.fsync(fh.fileno())
        os.replace(temp, path)
    except BaseException:
        try:
            os.unlink(temp)
        except OSError:
            pass
        raise

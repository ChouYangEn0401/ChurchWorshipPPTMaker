"""Who is on the other end of a request, and may it be here at all: local or remote, which Host, which origin.

A service binds 127.0.0.1, so the TCP peer is always this machine: cloudflared (its own tunnel or the platform's gate)
or a local program. A request is **local** only when nothing says otherwise -- no Cloudflare header at all, a
loopback peer *and* a loopback Host. Anything else is remote, so a tunnel request can never pass for a trusted local
one. `X-Forwarded-For` is ignored on purpose: cloudflared keeps entries the client sent.

- `client_from_headers(headers, peer)` -> `ClientInfo(ip, via_tunnel, country, user_agent, host, port, scheme)`;
  `ip` is `LOCAL_IP` for a local request, the visitor's address (`CF-Connecting-IP`) otherwise.
- `host_allowed(client, allowed, port=)`: local -> a loopback name (on `port`, when given); remote -> the Host is one
  of `allowed` (exact, or `*.domain` for any name under it). Stops DNS rebinding and old tunnel addresses.
- `public_hosts()`: what a remote Host may be when CSP runs this service -- `CSP_PUBLIC_HOSTS`, else the quick-tunnel
  pattern the platform's gate uses today.
- `same_origin(headers)`: a state-changing request's Origin (or Referer) is this site.
- `safe_next(value)`: where to go after logging in -- same-site paths only.
"""

from __future__ import annotations

import os
from dataclasses import dataclass
from typing import Iterable, Mapping
from urllib.parse import urlsplit

from isdcsp.net import LOCAL_IP, is_loopback_host_header, is_loopback_peer, normalize_ip, split_host_header

# Any of these means the request came through Cloudflare (its own tunnel or the platform's gate).
CF_HEADERS = ("cf-connecting-ip", "cf-ray", "cf-ipcountry", "cf-visitor", "cdn-loop")
QUICK_TUNNEL_HOSTS = ("*.trycloudflare.com",)


@dataclass(frozen=True)
class ClientInfo:
    ip: str               # the visitor's IP, or LOCAL_IP ("local") for this machine
    via_tunnel: bool      # True = remote
    country: str = ""
    user_agent: str = ""
    host: str = ""        # the Host header's name, lower case, without the port
    port: int | None = None
    scheme: str = "http"  # what the visitor's browser sees: https through Cloudflare

    @property
    def is_local(self) -> bool:
        return not self.via_tunnel

    local = is_local


def client_from_headers(headers: Mapping[str, str], peer_host: str | None) -> ClientInfo:
    """`headers`: lower-case names (Starlette's `request.headers` works as it is)."""
    user_agent = (headers.get("user-agent") or "")[:300]
    host, port = split_host_header(headers.get("host") or "")
    via_cf = any(name in headers for name in CF_HEADERS)
    if via_cf:
        cf_ip = (headers.get("cf-connecting-ip") or "").strip()
        ip = (normalize_ip(cf_ip) or "invalid") if cf_ip else "unknown"
        country = (headers.get("cf-ipcountry") or "").strip()[:8]
        # Quick tunnels are https-only towards the visitor, and so is the platform's gate.
        return ClientInfo(ip, True, country, user_agent, host, port, "https")
    if peer_host and not is_loopback_peer(peer_host):
        # Should be impossible (a service binds 127.0.0.1) -- remote, and never trusted as local.
        return ClientInfo(normalize_ip(peer_host) or "invalid", True, "", user_agent, host, port, "http")
    if not is_loopback_host_header(headers.get("host") or ""):
        return ClientInfo("unknown", True, "", user_agent, host, port, "http")
    return ClientInfo(LOCAL_IP, False, "", user_agent, host, port, "http")


def matches_host(host: str, allowed: Iterable[str]) -> bool:
    """`host` is one of `allowed`: an exact name, or `*.domain` -- a real subdomain only (`a.trycloudflare.com`, not
    `trycloudflare.com` itself and never `xtrycloudflare.com`)."""
    host = host.lower()
    for entry in allowed:
        entry = (entry or "").strip().lower()
        if not entry:
            continue
        if entry.startswith("*."):
            if host.endswith(entry[1:]) and len(host) > len(entry) - 1:
                return True
        elif host == entry:
            return True
    return False


def host_allowed(client: ClientInfo, allowed: Iterable[str] = (), *, port: int | None = None) -> bool:
    if client.is_local:
        return client.host in ("127.0.0.1", "localhost", "::1") and (port is None or client.port in (port, None))
    return client.port in (None, 443) and matches_host(client.host, allowed)


def public_hosts() -> tuple[str, ...]:
    """The remote Host names to accept when CSP runs this service: `CSP_PUBLIC_HOSTS` (comma separated, `*.domain`
    allowed), else the quick-tunnel pattern of the platform's gate. Empty outside the platform."""
    if not (os.environ.get("CSP_API") and os.environ.get("CSP_SERVICE_TOKEN")):
        return ()
    declared = [h.strip() for h in os.environ.get("CSP_PUBLIC_HOSTS", "").split(",") if h.strip()]
    return tuple(declared) or QUICK_TUNNEL_HOSTS


def same_origin(headers: Mapping[str, str]) -> bool:
    """A state-changing request must come from this site's own pages: Origin (or Referer) names this Host.
    No Origin and no Referer at all is refused too -- browsers send one of them on these requests."""
    source = headers.get("origin") or headers.get("referer") or ""
    if not source or source == "null":
        return False
    expected = (headers.get("x-forwarded-host") or headers.get("host") or "").lower()
    return (urlsplit(source).netloc or "").lower() == expected


def safe_next(value: str | None) -> str:
    """Only same-site absolute paths; blocks //evil.com, /\\evil.com, schemes and control characters."""
    if not value or not value.startswith("/") or value.startswith(("//", "/\\")):
        return "/"
    if any(ch in value for ch in "\\\r\n\t") or any(ord(ch) < 32 for ch in value):
        return "/"
    return value[:512]

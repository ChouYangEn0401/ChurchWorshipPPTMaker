"""`Site`: everything a service that keeps its own login needs, as one ASGI layer around the app.

    site = isdcsp.web.Site(password=lambda: db.kv_get("password_hash"))   # a team password, checked as typed
    app.add_middleware(isdcsp.web.Middleware, site=site)                    # FastAPI / Starlette
    # or: app = site.wrap(app)                                              # any ASGI app

For every request, in order:

1. The TCP peer must be this machine (a service binds 127.0.0.1; anything else is a misconfiguration).
2. Host: a local request names a loopback host (on `port`, when given); a remote one names an address this service
   is reachable at -- `allowed_hosts` (its own tunnel), plus the platform's when CSP runs it. Old tunnel addresses
   and DNS rebinding stop here.
3. `login_path` / `logout_path` are answered here (the built-in login page, or the service's own `page`).
4. Who: a local request is the owner. A remote one needs a session (cookie) unless the path is `public`; without one
   an API path (`api_prefix`) gets 401 JSON, a page is sent to the login page. `local_only` paths refuse remote
   requests outright. If no login can be completed from outside (nothing configured), remote requests are refused.
5. A state-changing request (and every WebSocket handshake) must come from this site's own pages (Origin/Referer);
   a remote one must also carry its session's CSRF token (`X-CSRF-Token`) -- except the login and logout forms.
6. The app runs with `isdcsp.principal(request)` (owner / member / anonymous), `isdcsp.web.client(request)` and
   `isdcsp.web.session(request)` set; every response gets the security headers it did not set itself.

Logging in: `factors` (default 1) of the ones available -- the password, a one-time code to a phone
(`isdcsp.codes`), the authenticator (`isdcsp.totp`) -- each a different one. Between factors the browser holds a
partial login (memory only, 5 minutes, 3 wrong answers). Wrong answers cost the visitor's network its login budget
(`LoginThrottle`); this machine is never counted. A login that needs more factors than are available is refused,
never quietly done with fewer.

The look is the project's business: `page(LoginView) -> html` renders the login page and `deny(Denial) -> html` the
refusals; the defaults are plain, readable on a phone, and work without JavaScript. Reasons and errors come as codes
(`Denial.reason`, `LoginView.error`) so a project can word them its own way.
"""

from __future__ import annotations

import html
import secrets
import threading
import time
from dataclasses import dataclass, field
from typing import Any, Awaitable, Callable, Iterable, Mapping
from urllib.parse import parse_qs, quote

from isdcsp import _env
from isdcsp.identity import Principal
from isdcsp.net import ban_key, is_loopback_peer
from isdcsp.passwords import PasswordHasher, ScryptParams
from isdcsp.throttle import Throttle
from isdcsp.tokens import new_token, same, token_digest
from isdcsp.web.client import ClientInfo, client_from_headers, host_allowed, public_hosts, safe_next, same_origin
from isdcsp.web.headers import BASE_CSP, security_headers
from isdcsp.web.sessions import Session, SessionStore, cookie_name, cookie_options

STATE_PRINCIPAL, STATE_CLIENT, STATE_SESSION = "isdcsp_principal", "isdcsp_client", "isdcsp_session"
UNSAFE = {"POST", "PUT", "PATCH", "DELETE"}
FACTORS = ("password", "code", "totp")
LABELS = {"password": "密碼", "code": "手機收到的登入碼", "totp": "驗證器"}
MAX_FORM_BYTES = 16 * 1024
PARTIAL_SECONDS = 300
PARTIAL_WRONG = 3
MAX_PARTIALS = 200

# Why a request was refused (`Denial.reason`), with the default wording.
DENIALS = {
    "peer": (403, "只接受這台電腦上的連線", "服務要只綁 127.0.0.1；外面的人要經過通道或平台的門口。"),
    "host": (421, "這個網址已經失效了", "請跟給你網址的人要新的網址。"),
    "not_open": (403, "這個網站還沒開放從外面使用", "要先在主機電腦上設定登入方式（例如密碼）。"),
    "local_only": (403, "這個功能只能在主機電腦上使用", ""),
    "origin": (403, "請求來源不對，已經擋下來了", "請直接從這個網站的頁面操作。"),
    "csrf": (403, "頁面放太久了，請重新整理後再試一次", ""),
    "login": (401, "登入已經過期，請重新整理頁面再登入一次", ""),
    "too_large": (413, "送出的資料太大", ""),
}

# Why a login step did not go through (`LoginView.error`), with the default wording.
LOGIN_ERRORS = {
    "wrong": "不對，再試一次。",
    "throttled": "錯太多次了，請過幾分鐘再試。",
    "code_refused": "剛剛要太多次登入碼了，請過幾分鐘再試。",
    "code_failed": "登入碼送不出去，請稍後再試。",
    "start_over": "這次登入已經失效（太久或錯太多次），請從頭再來一次。",
    "totp_unavailable": "驗證器現在不能用，請換一種方式。",
}


class LoginThrottle:
    """Wrong answers on the login page: per network (`ban_key`: an IPv4 address or an IPv6 /64) 8 in 15 minutes ->
    that network waits 15 minutes; everybody together 60 in 10 minutes -> everybody waits 10 minutes. This machine
    is never counted: nobody can lock the owner out of the computer in front of them."""

    def __init__(self, *, per_ip: tuple[int, float, float] = (8, 15 * 60, 15 * 60),
                 everyone: tuple[int, float, float] = (60, 10 * 60, 10 * 60),
                 clock: Callable[[], float] = time.monotonic) -> None:
        self.per_ip = Throttle(limit=per_ip[0], window_seconds=per_ip[1], block_seconds=per_ip[2], clock=clock)
        self.everyone = Throttle(limit=everyone[0], window_seconds=everyone[1], block_seconds=everyone[2],
                                 clock=clock)

    def blocked_for(self, client: ClientInfo) -> int:
        if client.is_local:
            return 0
        return max(self.per_ip.blocked_for(ban_key(client.ip)), self.everyone.blocked_for("*"))

    def failed(self, client: ClientInfo) -> None:
        if client.is_local:
            return
        self.per_ip.failed(ban_key(client.ip))
        self.everyone.failed("*")

    def succeeded(self, client: ClientInfo) -> None:
        self.per_ip.succeeded(ban_key(client.ip))


@dataclass
class _Partial:
    done: set[str] = field(default_factory=set)
    name: str = ""
    nonce: str = ""          # a code was sent: the tab's half
    created_at: float = 0.0
    wrong: int = 0


class _Partials:
    """Half-finished logins (some factors passed). Memory only: a restart forgets them, which is right."""

    def __init__(self, clock: Callable[[], float]) -> None:
        self._now = clock
        self._items: dict[str, _Partial] = {}
        self._lock = threading.Lock()

    def get(self, token: str | None) -> _Partial | None:
        if not token or len(token) > 100:
            return None
        with self._lock:
            item = self._items.get(token_digest(token))
            if item is not None and item.created_at < self._now() - PARTIAL_SECONDS:
                self._items.pop(token_digest(token), None)
                return None
            return item

    def start(self) -> tuple[str, _Partial]:
        token = new_token(32)
        now = self._now()
        with self._lock:
            if len(self._items) >= MAX_PARTIALS:
                self._items = {k: v for k, v in self._items.items() if v.created_at >= now - PARTIAL_SECONDS}
                while len(self._items) >= MAX_PARTIALS:
                    self._items.pop(next(iter(self._items)))
            item = self._items[token_digest(token)] = _Partial(created_at=now)
        return token, item

    def discard(self, token: str | None) -> None:
        if token:
            with self._lock:
                self._items.pop(token_digest(token), None)


@dataclass(frozen=True)
class LoginView:
    """What the login page should show. `error` is a code from `LOGIN_ERRORS` (`message` is the default text)."""

    title: str
    next: str
    offer: tuple[str, ...]            # the factors this page may ask for now
    needed: int                       # how many more to go
    done: tuple[str, ...] = ()
    error: str = ""
    message: str = ""
    nonce: str = ""                   # set: a code was sent, the page asks for it (and posts the nonce back)
    code_seconds: int = 0
    wait_seconds: int = 0             # error "throttled": how long
    name: str = ""
    ask_name: bool = True
    login_path: str = "/login"
    style_nonce: str = ""             # for an inline <style nonce=...>; the response's CSP allows exactly that
    scope: dict = field(default_factory=dict, repr=False)


@dataclass(frozen=True)
class Denial:
    """A refused request. `reason` is a key of `DENIALS`; `message`/`hint` are the default wording."""

    reason: str
    status: int
    message: str
    hint: str
    api: bool
    style_nonce: str = ""
    scope: dict = field(default_factory=dict, repr=False)


Page = Callable[[LoginView], str]
DenyPage = Callable[[Denial], str]


class Site:
    def __init__(self, *, password: Callable[[], str | None] | str | None = None,
                 hasher: PasswordHasher | None = None, factors: int = 1, totp: Any = None, codes: Any = None,
                 public: Iterable[str] = ("/healthz", "/favicon.ico", "/static/"), local_only: Iterable[str] = (),
                 allowed_hosts: Callable[[], Iterable[str]] | Iterable[str] = (), port: int | None = None,
                 login_path: str = "/login", logout_path: str = "/logout", api_prefix: str = "/api/",
                 store: SessionStore | None = None, throttle: LoginThrottle | None = None,
                 csp: Mapping[str, str] | None = None, cookie: str = "isdcsp_session", ask_name: bool = True,
                 title: str | None = None, page: Page | None = None, deny: DenyPage | None = None,
                 on_login: Callable[[Session], Any] | None = None, default_name: str = "訪客",
                 clock: Callable[[], float] = time.time) -> None:
        if factors < 1 or factors > len(FACTORS):
            raise ValueError("factors 要是 1 到 3")
        self._password = password if callable(password) else (lambda: password)
        self.hasher = hasher or PasswordHasher(ScryptParams(n=2 ** 14))
        self.factors = factors
        self._totp_choice = totp
        self._codes_choice = codes
        self.public = tuple(public) + (login_path,)
        self.local_only = tuple(local_only)
        self._allowed = allowed_hosts if callable(allowed_hosts) else (lambda: allowed_hosts)
        self.port = port
        self.login_path, self.logout_path, self.api_prefix = login_path, logout_path, api_prefix
        self._store = store
        self.throttle = throttle or LoginThrottle()
        self.csp = dict(csp or {})
        self.cookie = cookie
        self.ask_name = ask_name
        self.title = title or str(_env.manifest().get("service", {}).get("name") or "登入")
        self.page = page or default_page
        self.deny_page = deny or default_deny
        self.on_login = on_login
        self.default_name = default_name
        self._now = clock
        self.partials = _Partials(clock)
        self._partial_cookie = f"{cookie}_step"

    # ------------------------------------------------------------------ parts
    @property
    def sessions(self) -> SessionStore:
        if self._store is None:                       # here, not in __init__: it creates the data folder
            self._store = SessionStore(clock=self._now)
        return self._store

    def totp(self) -> Any:
        """The authenticator to offer, or None: `totp=` as given, else this service's own (`isdcsp.totp`) when it
        declared one in `[uses] totp`."""
        choice = self._totp_choice
        if choice is False:
            return None
        if choice is None or choice is True:
            from isdcsp import totp as _totp
            if choice is None and _totp.declared_mode() == "none":
                return None
            return _totp.for_service()
        return choice

    def codes(self) -> Any:
        """The login codes to offer, or None: `codes=` as given, else CSP's when `[uses] codes = "platform"` and CSP
        runs this service. (A service's own codes need its own channel: pass `codes=isdcsp.codes.for_service(
        deliver=...)`.)"""
        choice = self._codes_choice
        if choice is False:
            return None
        if choice is None:
            from isdcsp import codes as _codes
            if _codes.declared_mode() == "platform" and _env.in_platform():
                return _codes.for_service()
            return None
        if choice is True:
            from isdcsp import codes as _codes
            return _codes.for_service()
        return choice

    def available(self) -> tuple[str, ...]:
        """The factors a remote visitor could pass right now."""
        out = []
        if self._password():
            out.append("password")
        if self.codes() is not None:
            out.append("code")
        auth = self.totp()
        if auth is not None:
            try:
                if auth.configured:
                    out.append("totp")
            except Exception:
                pass
        return tuple(out)

    def allowed_hosts(self) -> set[str]:
        return {h for h in (*self._allowed(), *public_hosts()) if h}

    def logout_everyone(self) -> int:
        """End every session (the password changed, the tunnel closed): everybody logs in again."""
        return self.sessions.delete_all()

    def wrap(self, app: Any) -> "Middleware":
        return Middleware(app, site=self)

    # ------------------------------------------------------------------ checks used by the middleware
    def _is_public(self, path: str) -> bool:
        return any(path == p or (p.endswith("/") and path.startswith(p)) for p in self.public)

    def _is_local_only(self, path: str) -> bool:
        return bool(self.local_only) and path.startswith(self.local_only)


class Middleware:
    """The ASGI layer. Starlette/FastAPI: `app.add_middleware(Middleware, site=site)`."""

    def __init__(self, app: Any, site: Site) -> None:
        self.app = app
        self.site = site

    async def __call__(self, scope: dict, receive: Callable[[], Awaitable[dict]], send: Callable) -> None:
        if scope["type"] not in ("http", "websocket"):
            await self.app(scope, receive, send)
            return
        site = self.site
        websocket = scope["type"] == "websocket"
        headers = {k.decode("latin-1").lower(): v.decode("latin-1") for k, v in scope.get("headers", [])}
        peer = (scope.get("client") or ("", 0))[0]
        method = scope.get("method", "GET").upper()
        path = scope.get("path", "/")
        client = client_from_headers(headers, peer)
        api = path.startswith(site.api_prefix) or websocket

        if peer and not is_loopback_peer(peer):
            return await self._deny(scope, send, "peer", api, client)
        if not host_allowed(client, site.allowed_hosts(), port=site.port):
            return await self._deny(scope, send, "host", api, client)
        if not websocket and path == site.login_path:
            return await self._login(scope, receive, send, headers, client)
        if not websocket and path == site.logout_path and method == "POST":
            if not same_origin(headers):
                return await self._deny(scope, send, "origin", api, client)
            return await self._logout(scope, send, headers, client)

        cookies = _cookies(headers)
        session: Session | None = None
        if client.is_local:
            who = Principal("owner", "local", via="local")
        else:
            session = site.sessions.resolve(cookies.get(cookie_name(client, site.cookie)), client)
            if session is not None:
                who = Principal("member", session.name, via="login",
                                claims={"factors": list(session.factors), "session": session.id})
            elif site._is_public(path) and not site._is_local_only(path):
                who = Principal("anonymous", via="tunnel")
            else:
                if len(site.available()) < site.factors:
                    return await self._deny(scope, send, "not_open", api, client)
                if api:
                    return await self._deny(scope, send, "login", True, client)
                target = path + (("?" + scope["query_string"].decode("latin-1")) if scope.get("query_string") else "")
                return await _redirect(send, f"{site.login_path}?next={quote(safe_next(target))}",
                                       self._headers(client))
            if site._is_local_only(path):
                return await self._deny(scope, send, "local_only", api, client)

        if websocket or method in UNSAFE:
            origin = headers.get("origin")
            if websocket:
                cross = bool(origin) and (origin == "null" or not same_origin(headers))
                if cross:
                    return await self._deny(scope, send, "origin", True, client)
            elif not same_origin(headers):
                return await self._deny(scope, send, "origin", api, client)
            if not websocket and not client.is_local:
                sent = headers.get("x-csrf-token", "")
                if session is None or not same(sent, session.csrf):
                    return await self._deny(scope, send, "csrf", api, client)

        state = scope.setdefault("state", {})
        state[STATE_PRINCIPAL], state[STATE_CLIENT], state[STATE_SESSION] = who, client, session
        if websocket:
            await self.app(scope, receive, send)
            return
        extra = self._headers(client, own=False)

        async def send_with_headers(message: dict) -> None:
            if message["type"] == "http.response.start":
                present = {k.decode("latin-1").lower() for k, _ in message.get("headers", [])}
                message = dict(message, headers=list(message.get("headers", [])) +
                               [(k.encode("latin-1"), v.encode("latin-1")) for k, v in extra.items()
                                if k.lower() not in present])
            await send(message)

        await self.app(scope, receive, send_with_headers)

    # ------------------------------------------------------------------ helpers
    def _headers(self, client: ClientInfo, *, style_nonce: str = "", own: bool = True) -> dict[str, str]:
        """Security headers; `own` = a page this layer answers itself (login, refusals, redirects): never cached.
        The app's own responses keep whatever caching they chose."""
        csp = dict(self.site.csp)
        style = csp.get("style-src", BASE_CSP["style-src"])
        # The nonce is *added*: a project's own login page links its stylesheet ('self'). Where the site already allows
        # inline styles, a nonce would switch that off (CSP3 ignores 'unsafe-inline' next to a nonce), so none is added.
        if style_nonce and "'unsafe-inline'" not in style:
            csp["style-src"] = f"{style} 'nonce-{style_nonce}'"
        headers = security_headers(https=client.scheme == "https", csp=csp)
        if own:
            headers["Cache-Control"] = "no-store"
        return headers

    async def _deny(self, scope: dict, send: Callable, reason: str, api: bool, client: ClientInfo) -> None:
        status, message, hint = DENIALS[reason]
        if scope["type"] == "websocket":
            await send({"type": "websocket.close", "code": 1008})
            return
        if api:
            body = _json({"error": reason, "message": message, "hint": hint}).encode("utf-8")
            return await _respond(send, status, "application/json; charset=utf-8", body, self._headers(client))
        nonce = secrets.token_urlsafe(12)
        page = self.site.deny_page(Denial(reason, status, message, hint, api, nonce, scope))
        await _respond(send, status, "text/html; charset=utf-8", page.encode("utf-8"),
                       self._headers(client, style_nonce=nonce))

    async def _login(self, scope: dict, receive: Callable, send: Callable, headers: dict,
                     client: ClientInfo) -> None:
        site = self.site
        method = scope.get("method", "GET").upper()
        query = parse_qs(scope.get("query_string", b"").decode("latin-1"))
        next_path = safe_next((query.get("next") or ["/"])[0])
        if client.is_local:                       # this machine is the owner: nothing to log in to
            return await _redirect(send, next_path, self._headers(client))
        cookies = _cookies(headers)
        step_token = cookies.get(cookie_name(client, site._partial_cookie))
        partial = site.partials.get(step_token)
        if method not in ("POST",):
            return await self._show(scope, send, client, next_path, partial)
        if not same_origin(headers):
            return await self._deny(scope, send, "origin", False, client)
        form = await _read_form(receive)
        if form is None:
            return await self._deny(scope, send, "too_large", False, client)
        next_path = safe_next(form.get("next") or next_path)
        step = form.get("step", "password")
        name = (form.get("name") or (partial.name if partial else "")).strip()[:30]
        if step not in ("password", "code", "send-code", "totp"):
            step = "password"
        if partial is None and step_token:        # the half-finished login it pointed at is gone
            if step != "password" or not form.get("password"):
                return await self._show(scope, send, client, next_path, None, error="start_over", name=name,
                                        clear_step=True)
        available = site.available()
        if len(available) < site.factors:
            return await self._deny(scope, send, "not_open", False, client)
        wait = site.throttle.blocked_for(client)
        if wait:
            return await self._show(scope, send, client, next_path, partial, error="throttled", name=name,
                                    status=429, wait_seconds=wait)
        done = set(partial.done) if partial else set()

        if step == "send-code":
            codes = site.codes()
            if codes is None or "code" in done:
                return await self._show(scope, send, client, next_path, partial, name=name)
            started = codes.request(client.ip, context={"ua": client.user_agent, "where": client.country})
            if not started.ok:
                return await self._show(scope, send, client, next_path, partial, name=name, status=429,
                                        error="code_refused" if started.refused else "code_failed")
            token, partial = (step_token, partial) if partial else site.partials.start()
            partial.name, partial.nonce = name, started.nonce
            return await self._show(scope, send, client, next_path, partial, name=name, step_token=token,
                                    code_seconds=started.expires_in)

        factor = {"password": "password", "code": "code", "totp": "totp"}[step]
        if factor not in available or factor in done:
            return await self._show(scope, send, client, next_path, partial, name=name)
        ok = False
        if factor == "password":
            ok = site.hasher.verify(form.get("password", ""), site._password())
        elif factor == "code":
            codes = site.codes()
            ok = bool(codes is not None and partial is not None and partial.nonce
                      and codes.verify(partial.nonce, form.get("code", "")))   # the kept nonce, not the form's
        else:
            from isdcsp.totp import TotpError, only_digits
            try:
                ok = bool(site.totp().verify(only_digits(form.get("code")), counts=partial is not None))
            except TotpError:
                return await self._show(scope, send, client, next_path, partial, name=name,
                                        error="totp_unavailable")
        if not ok:
            site.throttle.failed(client)
            if partial is not None:
                partial.wrong += 1
                if partial.wrong >= PARTIAL_WRONG:
                    site.partials.discard(step_token)
                    return await self._show(scope, send, client, next_path, None, error="start_over", name=name,
                                            clear_step=True, status=401)
            return await self._show(scope, send, client, next_path, partial, error="wrong", name=name, status=401)

        site.throttle.succeeded(client)
        done.add(factor)
        if len(done) < site.factors:
            token, partial = (step_token, partial) if partial else site.partials.start()
            partial.done, partial.name, partial.nonce = done, name, ""
            return await self._show(scope, send, client, next_path, partial, name=name, step_token=token)

        site.partials.discard(step_token)
        old = cookies.get(cookie_name(client, site.cookie))
        site.sessions.delete(old)
        token, session = site.sessions.create(name or site.default_name, client,
                                              factors=[f for f in FACTORS if f in done])
        if site.on_login is not None:
            site.on_login(session)
        set_cookies = [_set_cookie(cookie_name(client, site.cookie), token, cookie_options(client)),
                       _clear_cookie(cookie_name(client, site._partial_cookie), client)]
        await _redirect(send, next_path, self._headers(client), cookies=set_cookies)

    async def _show(self, scope: dict, send: Callable, client: ClientInfo, next_path: str, partial: _Partial | None,
                    *, error: str = "", name: str = "", status: int = 200, step_token: str | None = None,
                    code_seconds: int = 0, clear_step: bool = False, wait_seconds: int = 0) -> None:
        site = self.site
        done = tuple(f for f in FACTORS if partial is not None and f in partial.done)
        offer = tuple(f for f in site.available() if f not in done)
        nonce = secrets.token_urlsafe(12)
        view = LoginView(title=site.title, next=next_path, offer=offer, needed=max(1, site.factors - len(done)),
                         done=done, error=error, message=LOGIN_ERRORS.get(error, ""),
                         nonce=partial.nonce if partial is not None else "", code_seconds=code_seconds,
                         wait_seconds=wait_seconds,
                         name=name or (partial.name if partial else ""), ask_name=site.ask_name,
                         login_path=site.login_path, style_nonce=nonce, scope=scope)
        cookies = []
        if step_token:
            cookies.append(_set_cookie(cookie_name(client, site._partial_cookie), step_token,
                                       dict(cookie_options(client, max_age=PARTIAL_SECONDS), samesite="strict")))
        elif clear_step:
            cookies.append(_clear_cookie(cookie_name(client, site._partial_cookie), client))
        await _respond(send, status, "text/html; charset=utf-8", site.page(view).encode("utf-8"),
                       self._headers(client, style_nonce=nonce), cookies=cookies)

    async def _logout(self, scope: dict, send: Callable, headers: dict, client: ClientInfo) -> None:
        site = self.site
        cookies = _cookies(headers)
        site.sessions.delete(cookies.get(cookie_name(client, site.cookie)))
        await _redirect(send, site.login_path, self._headers(client),
                        cookies=[_clear_cookie(cookie_name(client, site.cookie), client)])


# ---------------------------------------------------------------------------- accessors for handlers
def _state(request_or_scope: Any) -> Any:
    if isinstance(request_or_scope, dict):
        return request_or_scope.get("state", {})
    scope = getattr(request_or_scope, "scope", None)
    return scope.get("state", {}) if isinstance(scope, dict) else {}


def client(request_or_scope: Any) -> ClientInfo | None:
    """The `ClientInfo` the middleware worked out for this request."""
    return _state(request_or_scope).get(STATE_CLIENT)


def session(request_or_scope: Any) -> Session | None:
    """The session of a remote visitor who logged in (None for this machine and for public paths)."""
    return _state(request_or_scope).get(STATE_SESSION)


def csrf_token(request_or_scope: Any) -> str:
    """What the page should send back as `X-CSRF-Token` (empty for this machine, which does not need one)."""
    found = session(request_or_scope)
    return found.csrf if found is not None else ""


# ---------------------------------------------------------------------------- the default pages
_STYLE = ("body{font:16px/1.6 system-ui,-apple-system,'Segoe UI','Microsoft JhengHei',sans-serif;margin:0;"
          "background:#f4f5f2;color:#1d2420}main{max-width:26rem;margin:8vh auto;padding:0 1rem}"
          "h1{font-size:1.4rem;margin:0 0 1rem}form{background:#fff;border:1px solid #d5dad3;border-radius:10px;"
          "padding:1rem;margin:0 0 .8rem;display:grid;gap:.5rem}label{font-size:.9rem;color:#4a554d}"
          "input{font:inherit;padding:.6rem;border:1px solid #b9c2ba;border-radius:8px}"
          "button{font:inherit;padding:.6rem;border:0;border-radius:8px;background:#28634f;color:#fff}"
          ".err{background:#fbe9e6;border:1px solid #e6b8b0;border-radius:8px;padding:.6rem;margin:0 0 .8rem}"
          ".note{color:#4a554d;font-size:.9rem}"
          "@media (prefers-color-scheme:dark){body{background:#131815;color:#e3e8e4}"
          "form{background:#1b221e;border-color:#2c3630}input{background:#131815;color:#e3e8e4;border-color:#3a463f}"
          ".err{background:#3a1f1b;border-color:#5a2e27}.note,label{color:#a8b4ab}}")


def _e(value: Any) -> str:
    return html.escape(str(value), quote=True)


def default_page(view: LoginView) -> str:
    parts = [f"<!doctype html><html lang='zh-Hant'><head><meta charset='utf-8'>"
             f"<meta name='viewport' content='width=device-width, initial-scale=1'><title>{_e(view.title)}</title>"
             f"<style nonce='{_e(view.style_nonce)}'>{_STYLE}</style></head><body><main>"
             f"<h1>{_e(view.title)}</h1>"]
    if view.done:
        parts.append(f"<p class='note'>已經過了：{_e('、'.join(LABELS[f] for f in view.done))}。"
                     f"再一種就好。</p>" if view.needed == 1 else
                     f"<p class='note'>已經過了：{_e('、'.join(LABELS[f] for f in view.done))}。"
                     f"還要 {view.needed} 種。</p>")
    elif view.needed > 1:
        parts.append(f"<p class='note'>從外面登入要 {view.needed} 種方式。</p>")
    if view.message:
        parts.append(f"<p class='err' role='alert'>{_e(view.message)}</p>")
    hidden = f"<input type='hidden' name='next' value='{_e(view.next)}'>"
    name = (f"<label for='name'>你的名字</label><input id='name' name='name' value='{_e(view.name)}' "
            f"autocomplete='name' maxlength='30'>") if view.ask_name and not view.done else ""
    if "password" in view.offer:
        parts.append(f"<form method='post' action='{_e(view.login_path)}'>{hidden}"
                     f"<input type='hidden' name='step' value='password'>{name}"
                     "<label for='password'>密碼</label><input id='password' name='password' type='password' "
                     "autocomplete='current-password' required><button>登入</button></form>")
        name = ""
    if "code" in view.offer:
        if view.nonce:
            parts.append(f"<form method='post' action='{_e(view.login_path)}'>{hidden}"
                         f"<input type='hidden' name='step' value='code'>"
                         f"<input type='hidden' name='nonce' value='{_e(view.nonce)}'>"
                         f"<label for='code'>手機收到的 6 位數</label><input id='code' name='code' "
                         "inputmode='numeric' autocomplete='one-time-code' maxlength='12' required>"
                         f"<button>送出</button><span class='note'>"
                         f"{_e(view.code_seconds or 90)} 秒內有效。</span></form>")
        else:
            parts.append(f"<form method='post' action='{_e(view.login_path)}'>{hidden}"
                         f"<input type='hidden' name='step' value='send-code'>{name}"
                         "<button>把登入碼傳到手機</button></form>")
            name = ""
    if "totp" in view.offer:
        parts.append(f"<form method='post' action='{_e(view.login_path)}'>{hidden}"
                     f"<input type='hidden' name='step' value='totp'>{name}"
                     "<label for='totp'>驗證器上的 6 位數</label><input id='totp' name='code' inputmode='numeric' "
                     "autocomplete='one-time-code' maxlength='12' required><button>送出</button></form>")
    parts.append("</main></body></html>")
    return "".join(parts)


def default_deny(denial: Denial) -> str:
    return (f"<!doctype html><html lang='zh-Hant'><head><meta charset='utf-8'>"
            f"<meta name='viewport' content='width=device-width, initial-scale=1'><title>{_e(denial.message)}</title>"
            f"<style nonce='{_e(denial.style_nonce)}'>{_STYLE}</style></head><body><main>"
            f"<h1>{_e(denial.message)}</h1>" + (f"<p class='note'>{_e(denial.hint)}</p>" if denial.hint else "")
            + "</main></body></html>")


# ---------------------------------------------------------------------------- ASGI plumbing
def _cookies(headers: Mapping[str, str]) -> dict[str, str]:
    """A tolerant Cookie header parser: one broken pair must not hide the others."""
    out: dict[str, str] = {}
    for part in headers.get("cookie", "").split(";"):
        name, sep, value = part.strip().partition("=")
        if sep and name and name not in out:
            out[name] = value.strip().strip('"')
    return out


def _set_cookie(name: str, value: str, options: Mapping[str, Any]) -> str:
    parts = [f"{name}={value}", f"Max-Age={int(options.get('max_age', 0))}", f"Path={options.get('path', '/')}"]
    if options.get("httponly", True):
        parts.append("HttpOnly")
    parts.append(f"SameSite={str(options.get('samesite', 'lax')).capitalize()}")
    if options.get("secure"):
        parts.append("Secure")
    return "; ".join(parts)


def _clear_cookie(name: str, client: ClientInfo) -> str:
    return _set_cookie(name, "", dict(cookie_options(client), max_age=0))


async def _read_form(receive: Callable) -> dict[str, str] | None:
    body = b""
    while True:
        message = await receive()
        body += message.get("body", b"")
        if len(body) > MAX_FORM_BYTES:
            return None
        if not message.get("more_body"):
            break
    fields = parse_qs(body.decode("utf-8", "replace"), keep_blank_values=True, max_num_fields=20)
    return {k: v[0] for k, v in fields.items()}


def _json(data: dict) -> str:
    import json
    return json.dumps(data, ensure_ascii=False)


async def _respond(send: Callable, status: int, content_type: str, body: bytes, headers: Mapping[str, str],
                   *, cookies: Iterable[str] = ()) -> None:
    raw = [(b"content-type", content_type.encode("latin-1")), (b"content-length", str(len(body)).encode())]
    raw += [(k.encode("latin-1"), v.encode("latin-1")) for k, v in headers.items()]
    raw += [(b"set-cookie", c.encode("latin-1")) for c in cookies]
    await send({"type": "http.response.start", "status": status, "headers": raw})
    await send({"type": "http.response.body", "body": body})


async def _redirect(send: Callable, location: str, headers: Mapping[str, str], *, cookies: Iterable[str] = ()) -> None:
    # A header is latin-1: a path with 中文 in it is percent-encoded, the URL's own punctuation is left alone.
    location = quote(location, safe=":/?#[]@!$&'()*+,;=%~-._")
    raw = [(b"location", location.encode("ascii")), (b"content-length", b"0")]
    raw += [(k.encode("latin-1"), v.encode("latin-1")) for k, v in headers.items()]
    raw += [(b"set-cookie", c.encode("latin-1")) for c in cookies]
    await send({"type": "http.response.start", "status": 303, "headers": raw})
    await send({"type": "http.response.body", "body": b""})

"""`isdcsp.web`: the website half of a service that keeps its own login (1.2, ADR 0035).

**The whole thing** -- one layer around the app: Host checks, sessions, CSRF, the login page with up to three factors
(password / a code to a phone / the authenticator), the security headers:

    site = isdcsp.web.Site(password=lambda: db.kv_get("password_hash"), local_only=("/api/settings",))
    app.add_middleware(isdcsp.web.Middleware, site=site)          # FastAPI / Starlette; any ASGI app: site.wrap(app)

    @app.get("/")
    def home(request):
        who = isdcsp.principal(request)          # owner (this machine) / member (logged in) / anonymous (public path)
        token = isdcsp.web.csrf_token(request)   # put it in the page; send it back as X-CSRF-Token on changes

Keep your own look with `page=` (renders a `LoginView`) and `deny=` (renders a `Denial`); the logic stays here.
How many factors a visitor needs is the project's choice (`factors=1` by default); this machine never logs in.

**The toolbox** -- each piece on its own, for a project that keeps its own middleware:

    client_from_headers(headers, peer)  -> ClientInfo   this machine or a visitor, which IP, which Host, http(s)
    host_allowed(client, allowed, port=)                local: a loopback name; remote: one of `allowed` (*.domain ok)
    same_origin(headers)                                a change request came from this site's own pages
    safe_next(path)                                     where to go after logging in: same-site paths only
    security_headers(https=, csp=)                      CSP, nosniff, no framing, ... (HSTS on https)
    SessionStore(path)                                  logged-in browsers: digests only, idle + absolute expiry
    cookie_name(client, base) / cookie_options(client)  `__Host-` + Secure on https, HttpOnly, SameSite=Lax

The platform's own pages use the same pieces (`csp_platform.security.client`, `csp_platform.web.headers`), so "is this
request from this machine" has one answer everywhere.
"""

from __future__ import annotations

from isdcsp.web.client import (
    CF_HEADERS,
    QUICK_TUNNEL_HOSTS,
    ClientInfo,
    client_from_headers,
    host_allowed,
    matches_host,
    public_hosts,
    safe_next,
    same_origin,
)
from isdcsp.web.headers import BASE_CSP, PERMISSIONS_POLICY, content_security_policy, security_headers
from isdcsp.web.sessions import Session, SessionStore, cookie_name, cookie_options
from isdcsp.web.site import (
    DENIALS,
    LOGIN_ERRORS,
    Denial,
    LoginThrottle,
    LoginView,
    Middleware,
    Site,
    client,
    csrf_token,
    default_deny,
    default_page,
    session,
)

__all__ = ["BASE_CSP", "CF_HEADERS", "DENIALS", "LOGIN_ERRORS", "PERMISSIONS_POLICY", "QUICK_TUNNEL_HOSTS",
           "ClientInfo", "Denial", "LoginThrottle", "LoginView", "Middleware", "Session", "SessionStore", "Site",
           "client", "client_from_headers", "content_security_policy", "cookie_name", "cookie_options", "csrf_token",
           "default_deny", "default_page", "host_allowed", "matches_host", "public_hosts", "safe_next", "same_origin",
           "security_headers", "session"]

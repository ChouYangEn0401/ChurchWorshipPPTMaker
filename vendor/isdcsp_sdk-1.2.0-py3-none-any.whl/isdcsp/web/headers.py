"""Security response headers: the same base for the platform's pages and every service's.

`BASE_CSP` allows nothing from another origin -- no third-party scripts, styles, frames or images. A site loosens
or tightens it per directive (`content_security_policy({"style-src": "'self' 'unsafe-inline'"})`); the platform
builds its profiles (an uploaded file, an information-station report) the same way.

`security_headers(client, csp=...)` is the set a page should carry: CSP, `nosniff`, no framing, `same-origin`
referrers (not `no-referrer`: browsers then send `Origin: null` on same-origin POSTs, which defeats an Origin check),
`Permissions-Policy` off for every device, COOP, no indexing, and HSTS when the visitor is on https.
"""

from __future__ import annotations

from typing import Mapping

BASE_CSP: dict[str, str] = {
    "default-src": "'none'",
    "script-src": "'self'",
    "style-src": "'self'",
    "img-src": "'self' data: blob:",
    "font-src": "'self'",
    "connect-src": "'self'",
    "media-src": "'self' blob:",
    "worker-src": "'self' blob:",
    "manifest-src": "'self'",
    "form-action": "'self'",
    "frame-ancestors": "'none'",
    "base-uri": "'none'",
    "object-src": "'none'",
}

PERMISSIONS_POLICY = ("camera=(), microphone=(), geolocation=(), payment=(), usb=(), serial=(), "
                      "bluetooth=(), hid=(), midi=(), display-capture=(), browsing-topics=()")


def content_security_policy(overrides: Mapping[str, str] | None = None) -> str:
    directives = dict(BASE_CSP) | dict(overrides or {})
    # A valueless directive (`sandbox`) is a directive name on its own, not a name with a blank after it.
    return "; ".join(f"{k} {v}".strip() for k, v in directives.items())


def security_headers(*, https: bool, csp: Mapping[str, str] | None = None) -> dict[str, str]:
    headers = {
        "Content-Security-Policy": content_security_policy(csp),
        "X-Content-Type-Options": "nosniff",
        "X-Frame-Options": "DENY",
        "Referrer-Policy": "same-origin",
        "Permissions-Policy": PERMISSIONS_POLICY,
        "Cross-Origin-Opener-Policy": "same-origin",
        "X-Robots-Tag": "noindex, nofollow, noarchive",
    }
    if https:
        headers["Strict-Transport-Security"] = "max-age=31536000"
    return headers

"""Logged-in browsers of a service that keeps its own login: a random cookie, and a row holding only its digest.

    store = isdcsp.web.SessionStore()                 # <project>/data/isdcsp/sessions.sqlite3
    token, session = store.create("Amy", client, factors=("password",))
    store.resolve(token, client)                      # -> Session, or None (unknown, expired, another address)

- The cookie carries a 32-byte random token; the table keeps its SHA-256, so a copied file logs nobody in.
- Idle and absolute expiry (`idle_seconds`, default 14 days; `max_seconds`, default 60 days).
- A session belongs to the address it was made on (`host`): a cookie is already bound to one host by the browser
  (`__Host-` cookies over https), and a session made on an old tunnel address does not follow to a new one.
- `last_seen` is written at most once a minute: reading a page does not write the database every time.
- Each session has its own CSRF token (`session.csrf`) for the page to send back on changes (`X-CSRF-Token`).

SQLite from the standard library, one connection guarded by a lock, WAL mode: a few sessions per service need no
more, and nothing stays in memory but the connection.
"""

from __future__ import annotations

import re
import sqlite3
import threading
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Iterable

from isdcsp.tokens import new_token, token_digest
from isdcsp.web.client import ClientInfo

IDLE_SECONDS = 14 * 24 * 3600
MAX_SECONDS = 60 * 24 * 3600
TOUCH_EVERY_SECONDS = 60
MAX_TOKEN_CHARS = 100
_ID_RE = re.compile(r"^[0-9a-f]{8,64}$")

_SCHEMA = """
CREATE TABLE IF NOT EXISTS isdcsp_sessions (
    digest TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    csrf TEXT NOT NULL,
    host TEXT NOT NULL,
    factors TEXT NOT NULL,
    created_at REAL NOT NULL,
    last_seen REAL NOT NULL,
    ip TEXT NOT NULL,
    user_agent TEXT NOT NULL
)
"""


@dataclass(frozen=True)
class Session:
    id: str                  # the first 12 hex digits of the digest: enough to name one in a list, useless to log in
    name: str
    csrf: str
    host: str
    factors: tuple[str, ...]
    created_at: float
    last_seen: float
    ip: str
    user_agent: str

    def public(self) -> dict:
        """What a session list may show (no CSRF token)."""
        return {"id": self.id, "name": self.name, "host": self.host, "factors": list(self.factors),
                "created_at": self.created_at, "last_seen": self.last_seen, "ip": self.ip,
                "user_agent": self.user_agent}


class SessionStore:
    def __init__(self, path: Path | str | None = None, *, idle_seconds: float = IDLE_SECONDS,
                 max_seconds: float = MAX_SECONDS, clock: Callable[[], float] = time.time) -> None:
        if path is None:
            from isdcsp.tools import data_dir
            path = data_dir("isdcsp") / "sessions.sqlite3"
        self.path = Path(path)
        self.idle_seconds = idle_seconds
        self.max_seconds = max_seconds
        self._now = clock
        self._lock = threading.Lock()
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._conn = sqlite3.connect(str(self.path), check_same_thread=False, isolation_level=None)
        self._conn.row_factory = sqlite3.Row
        with self._lock:
            self._conn.execute("PRAGMA journal_mode=WAL")
            self._conn.execute(_SCHEMA)

    # ------------------------------------------------------------------ the life of one session
    def create(self, name: str, client: ClientInfo, *, factors: Iterable[str] = ("password",)) -> tuple[str, Session]:
        """A new session; returns (raw token for the cookie, the session). Expired rows are swept on the way."""
        token = new_token(32)
        now = self._now()
        row = (token_digest(token), (name or "").strip()[:30] or "訪客", new_token(24), client.host,
               ",".join(factors), now, now, client.ip, client.user_agent[:200])
        with self._lock:
            self._conn.execute("INSERT INTO isdcsp_sessions(digest, name, csrf, host, factors, created_at, last_seen,"
                               " ip, user_agent) VALUES(?,?,?,?,?,?,?,?,?)", row)
            self._sweep(now)
        return token, _session(dict(zip(("digest", "name", "csrf", "host", "factors", "created_at", "last_seen",
                                          "ip", "user_agent"), row)))

    def resolve(self, token: str | None, client: ClientInfo) -> Session | None:
        """The live session for this cookie on this address, or None. Touches `last_seen` (at most once a minute)."""
        if not token or len(token) > MAX_TOKEN_CHARS:
            return None
        digest = token_digest(token)
        now = self._now()
        with self._lock:
            row = self._conn.execute("SELECT * FROM isdcsp_sessions WHERE digest = ?", (digest,)).fetchone()
            if row is None:
                return None
            if row["last_seen"] < now - self.idle_seconds or row["created_at"] < now - self.max_seconds:
                self._conn.execute("DELETE FROM isdcsp_sessions WHERE digest = ?", (digest,))
                return None
            if row["host"] != client.host:
                return None
            if now - row["last_seen"] > TOUCH_EVERY_SECONDS:
                self._conn.execute("UPDATE isdcsp_sessions SET last_seen = ?, ip = ? WHERE digest = ?",
                                   (now, client.ip, digest))
        return _session(dict(row))

    def delete(self, token: str | None) -> None:
        if token and len(token) <= MAX_TOKEN_CHARS:
            with self._lock:
                self._conn.execute("DELETE FROM isdcsp_sessions WHERE digest = ?", (token_digest(token),))

    def delete_all(self) -> int:
        """Everybody logs in again (the password changed, the tunnel closed)."""
        with self._lock:
            return self._conn.execute("DELETE FROM isdcsp_sessions").rowcount

    def delete_by_id(self, session_id: str) -> int:
        """End one session from a list (`Session.id`); refuses a prefix that matches more than one."""
        if not _ID_RE.match(session_id or ""):      # hex only: `%` or `_` would be LIKE wildcards
            return 0
        with self._lock:
            rows = self._conn.execute("SELECT digest FROM isdcsp_sessions WHERE digest LIKE ?",
                                      (session_id + "%",)).fetchall()
            if len(rows) != 1:
                return 0
            return self._conn.execute("DELETE FROM isdcsp_sessions WHERE digest = ?", (rows[0]["digest"],)).rowcount

    def active(self) -> list[Session]:
        now = self._now()
        with self._lock:
            rows = self._conn.execute("SELECT * FROM isdcsp_sessions WHERE last_seen >= ? AND created_at >= ? "
                                      "ORDER BY last_seen DESC",
                                      (now - self.idle_seconds, now - self.max_seconds)).fetchall()
        return [_session(dict(r)) for r in rows]

    def close(self) -> None:
        with self._lock:
            self._conn.close()

    def _sweep(self, now: float) -> None:
        self._conn.execute("DELETE FROM isdcsp_sessions WHERE last_seen < ? OR created_at < ?",
                           (now - self.idle_seconds, now - self.max_seconds))


def _session(row: dict) -> Session:
    return Session(id=row["digest"][:12], name=row["name"], csrf=row["csrf"], host=row["host"],
                   factors=tuple(f for f in str(row["factors"]).split(",") if f), created_at=row["created_at"],
                   last_seen=row["last_seen"], ip=row["ip"], user_agent=row["user_agent"])


def cookie_name(client: ClientInfo, base: str = "isdcsp_session") -> str:
    """`__Host-<base>` over https (this exact address, https only, path /); `<base>` on http://127.0.0.1, where
    browsers do not reliably send Secure cookies."""
    return f"__Host-{base}" if client.scheme == "https" else base


def cookie_options(client: ClientInfo, *, max_age: float = MAX_SECONDS) -> dict:
    """The rest of the session cookie: HttpOnly, SameSite=Lax (a link from LINE must arrive logged in), Secure on
    https, path /. Pass to `response.set_cookie(name, token, **options)` (Starlette, FastAPI)."""
    return {"max_age": int(max_age), "path": "/", "httponly": True, "samesite": "lax",
            "secure": client.scheme == "https"}

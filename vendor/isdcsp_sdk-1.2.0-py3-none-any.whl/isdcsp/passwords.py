"""Passwords: scrypt hashing, and generated passwords people can type from a phone.

One format everywhere -- `scrypt$n$r$p$salt_b64$hash_b64` -- so a hash written by the platform, by a service, or by a
project before it used the SDK (PPTMaker's team password) verifies with the same code. The parameters travel with
the hash: an old hash keeps verifying after the default cost goes up.

- `PasswordHasher(params, normalize=None)`: `hash(password)`, `verify(password, stored)`. `verify(pw, None)` checks a
  dummy hash, so "no such user" and "wrong password" take the same time. `normalize` rewrites what a person typed
  before hashing and checking: the platform's generated passwords pass `normalize_password` (case, dashes, spaces
  and the look-alikes O/I/L do not matter); a password a person chose is checked as typed (the default).
- `hash_password` / `verify_password`: the same with default parameters, for a service's one team password.
- `generate_password()`: 80 random bits as XXXX-XXXX-XXXX-XXXX in Crockford base32.
"""

from __future__ import annotations

import base64
import hashlib
import hmac
import secrets
from dataclasses import dataclass
from typing import Callable

CROCKFORD = "0123456789ABCDEFGHJKMNPQRSTVWXYZ"
_NORMALIZE = str.maketrans({"O": "0", "I": "1", "L": "1", "-": None, " ": None, "_": None})
PASSWORD_CHARS = 16  # 16 * 5 bits = 80 bits of entropy


def generate_password() -> str:
    raw = "".join(secrets.choice(CROCKFORD) for _ in range(PASSWORD_CHARS))
    return "-".join(raw[i:i + 4] for i in range(0, PASSWORD_CHARS, 4))


def normalize_password(text: str) -> str:
    """For generated passwords: typing it from a phone, case, dashes, spaces and O/I/L do not matter."""
    return text.strip().upper().translate(_NORMALIZE)


@dataclass(frozen=True)
class ScryptParams:
    n: int = 2 ** 15
    r: int = 8
    p: int = 1

    @property
    def maxmem(self) -> int:
        return 128 * self.n * self.r * self.p + 16 * 1024 * 1024


class PasswordHasher:
    """Format: scrypt$n$r$p$salt_b64$hash_b64."""

    def __init__(self, params: ScryptParams = ScryptParams(),
                 normalize: Callable[[str], str] | None = None) -> None:
        self.params = params
        self.normalize = normalize
        self._dummy = self.hash("dummy-password-for-timing")

    def _prepare(self, password: str) -> str:
        return self.normalize(password) if self.normalize else password

    def hash(self, password: str) -> str:
        salt = secrets.token_bytes(16)
        digest = self._derive(self._prepare(password), salt, self.params)
        p = self.params
        return f"scrypt${p.n}${p.r}${p.p}${_b64(salt)}${_b64(digest)}"

    def verify(self, password: str, stored: str | None) -> bool:
        """Constant-ish time: when `stored` is None a dummy hash is checked so unknown users take as long."""
        target = stored or self._dummy
        try:
            scheme, n, r, p, salt_b64, hash_b64 = target.split("$")
            if scheme != "scrypt":
                return False
            params = ScryptParams(int(n), int(r), int(p))
            expected = base64.b64decode(hash_b64)
            actual = self._derive(self._prepare(password), base64.b64decode(salt_b64), params, len(expected))
        except (ValueError, TypeError):
            return False
        return hmac.compare_digest(actual, expected) and stored is not None

    @staticmethod
    def _derive(password: str, salt: bytes, params: ScryptParams, length: int = 32) -> bytes:
        return hashlib.scrypt(password.encode("utf-8"), salt=salt, n=params.n, r=params.r, p=params.p,
                              maxmem=params.maxmem, dklen=length)


def _b64(data: bytes) -> str:
    return base64.b64encode(data).decode("ascii")


_default: PasswordHasher | None = None


def _hasher() -> PasswordHasher:
    global _default
    if _default is None:              # built on first use: the dummy hash costs one scrypt
        _default = PasswordHasher(ScryptParams(n=2 ** 14))
    return _default


def hash_password(password: str) -> str:
    """A person's chosen password (checked as typed), at the cost a service's login can afford (n = 2^14)."""
    return _hasher().hash(password)


def verify_password(password: str, stored: str | None) -> bool:
    return _hasher().verify(password, stored)

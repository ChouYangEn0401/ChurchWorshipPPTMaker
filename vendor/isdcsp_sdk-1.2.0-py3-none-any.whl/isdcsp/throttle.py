"""Too many wrong answers from one key -> that key waits a while. One small rule, used in several places.

    limiter = isdcsp.throttle.Throttle(limit=5, window_seconds=900, block_seconds=900)
    if limiter.blocked_for(key): ...           # seconds still to wait (0 = go ahead)
    if limiter.failed(key): ...                # True exactly when this failure started a block
    limiter.succeeded(key)                     # a right answer clears the key's count

A key is whatever is being protected or blamed: a visitor's IP, a service id, or `"*"` for "everybody at once".

Memory stays bounded: windows are trimmed as they are touched, empty keys are dropped, and past `max_keys` the
oldest keys are forgotten first (forgetting can only make the limiter kinder, never stricter).
"""

from __future__ import annotations

import threading
import time
from collections import deque
from typing import Callable


class Throttle:
    def __init__(self, *, limit: int, window_seconds: float, block_seconds: float,
                 clock: Callable[[], float] = time.monotonic, max_keys: int = 10_000) -> None:
        if limit < 1 or window_seconds <= 0 or block_seconds <= 0:
            raise ValueError("Throttle 需要 limit >= 1，而且時間要大於 0")
        self.limit = limit
        self.window = float(window_seconds)
        self.block = float(block_seconds)
        self._clock = clock
        self._max_keys = max_keys
        self._lock = threading.Lock()
        self._fails: dict[str, deque[float]] = {}
        self._blocked: dict[str, float] = {}

    def blocked_for(self, key: str) -> int:
        """Whole seconds `key` still has to wait; 0 when it may try now."""
        now = self._clock()
        with self._lock:
            until = self._blocked.get(key, 0.0)
            if until <= now:
                self._blocked.pop(key, None)
                return 0
            return int(until - now) + 1

    def failed(self, key: str) -> bool:
        """Count one wrong answer for `key`. True when this one reached the limit (the block starts now)."""
        now = self._clock()
        with self._lock:
            hits = self._fails.get(key)
            if hits is None:
                if len(self._fails) >= self._max_keys:
                    self._fails.pop(next(iter(self._fails)))
                hits = self._fails[key] = deque()
            hits.append(now)
            while hits and hits[0] <= now - self.window:
                hits.popleft()
            if len(hits) < self.limit:
                return False
            del self._fails[key]
            if len(self._blocked) >= self._max_keys:
                self._blocked.pop(next(iter(self._blocked)))
            self._blocked[key] = now + self.block
            return True

    def succeeded(self, key: str) -> None:
        with self._lock:
            self._fails.pop(key, None)

    def clear(self, key: str | None = None) -> None:
        """Forget `key` (or everything): an owner lifting a block by hand."""
        with self._lock:
            if key is None:
                self._fails.clear()
                self._blocked.clear()
            else:
                self._fails.pop(key, None)
                self._blocked.pop(key, None)

    def prune(self) -> None:
        """Drop expired blocks and empty windows (a maintenance job may call this; nothing depends on it)."""
        now = self._clock()
        with self._lock:
            self._blocked = {k: t for k, t in self._blocked.items() if t > now}
            for key in list(self._fails):
                hits = self._fails[key]
                while hits and hits[0] <= now - self.window:
                    hits.popleft()
                if not hits:
                    del self._fails[key]

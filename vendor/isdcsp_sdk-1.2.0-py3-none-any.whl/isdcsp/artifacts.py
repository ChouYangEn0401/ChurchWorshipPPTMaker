"""`isdcsp.artifacts.put(path, category=...)`: publish a report to the platform's information station (資訊站, O2b).

    import isdcsp
    isdcsp.artifacts.put("out/2026-10-06.html", category="daily-briefing", title="每日簡報 10/06")

On the platform (needs `[uses] artifacts = "write"`, approved): the bytes go to `POST /api/v1/artifacts`, the platform
keeps the version and decides who may read it (every category starts as the owner's only). The same bytes as the
latest version make no new version.

Without the platform (local mode): the file is copied to `<project>/data/artifacts/<category>/<name>`, so a tool that
publishes still runs -- and its output is still somewhere you can open.

Allowed: .html .htm .png .jpg .jpeg .gif .webp .txt .md .csv .json .log .pdf (the platform checks again).
"""

from __future__ import annotations

import re
import shutil
from pathlib import Path
from typing import Any

from isdcsp import _env, _http
from isdcsp.tools import data_dir

CATEGORY_RE = re.compile(r"^[a-z0-9][a-z0-9_-]{0,39}$")
SUFFIXES = {".html", ".htm", ".png", ".jpg", ".jpeg", ".gif", ".webp", ".txt", ".md", ".csv", ".json", ".log", ".pdf"}


def put(path: str | Path, *, category: str, name: str | None = None, title: str = "") -> dict[str, Any]:
    """Publish one file. Returns what the platform stored (`status`: stored | unchanged), or `{"local": path}`."""
    source = Path(path)
    if not source.is_file():
        raise FileNotFoundError(f"找不到要推上去的檔案：{source}")
    if not CATEGORY_RE.match(category or ""):
        raise ValueError("category 只能是小寫英數字、_、-（最多 40 字），例如 daily-briefing")
    name = name or source.name
    if Path(name).suffix.lower() not in SUFFIXES:
        raise ValueError("資訊站只收 " + " ".join(sorted(SUFFIXES)))
    if not _env.in_platform():
        target = data_dir("artifacts", category) / Path(name).name
        shutil.copyfile(source, target)
        return {"local": str(target)}
    return _http.request_bytes("POST", "/artifacts", source.read_bytes(),
                               params={"category": category, "name": name, "title": title})

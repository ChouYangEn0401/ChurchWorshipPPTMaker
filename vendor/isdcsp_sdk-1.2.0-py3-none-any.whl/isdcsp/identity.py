"""Who is asking? (BLUEPRINT §5.5) -- the one question a service must never answer by itself.

- A request that came **through the gate** carries `X-CSP-Assertion`: an Ed25519-signed statement from the
  platform (who, which groups, for this service only, 60 s). It is verified with the platform's public keys.
  Through the gate *without* a valid one: refused for `auth = "platform"` services; for `auth = "own"` it is an
  anonymous visitor and the service's own login decides.
- A request **straight from this machine** (loopback peer, local Host, no forwarding headers) is the owner.
- Anything else -- a peer that is not loopback, a strange Host -- is refused: the service was reachable some
  way it should not be (bound to 0.0.0.0, DNS rebinding).

Never "it came from 127.0.0.1, so it is the owner" alone: the gate itself connects from 127.0.0.1.

**This module is the contract, and the only implementation of it.** The assertion format, what makes one valid,
and the JWKS shape its keys are published in are defined here, in the upper layer -- `csp_platform` imports
`verify_assertion`, `key_id` and `jwk` from here rather than keeping its own copy, and only *signing* (which
needs the private key, and therefore the platform's secret store) lives over there. The SDK never imports the
platform; the platform importing the SDK is the normal direction.
"""

from __future__ import annotations

import base64
import hashlib
import json
import threading
import time
from dataclasses import dataclass, field
from typing import Any, Iterable, Mapping

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey

from isdcsp import _env, _http

HEADER = "x-csp-assertion"
ISSUER = "csp"
LIFETIME_SECONDS = 60
LEEWAY_SECONDS = 30
MAX_TOKEN = 4096
FORWARD_HEADERS = ("cf-connecting-ip", "cf-ray", "cf-visitor", "x-forwarded-for", "x-forwarded-host",
                   "x-forwarded-proto", "forwarded")
LOOPBACK = ("127.0.0.1", "::1", "localhost")


class IdentityError(Exception):
    """The assertion is missing, malformed, forged, expired or meant for another service."""


class Refused(Exception):
    def __init__(self, status: int, reason: str) -> None:
        super().__init__(reason)
        self.status = status
        self.reason = reason


@dataclass(frozen=True)
class Principal:
    kind: str                      # "owner" | "member" | "anonymous"
    name: str = ""
    groups: tuple[str, ...] = ()
    via: str = "local"             # "local" (this machine) | "gate" (through the platform's gate)
    claims: dict = field(default_factory=dict, compare=False)

    @property
    def is_owner(self) -> bool:
        return self.kind == "owner"

    @property
    def is_anonymous(self) -> bool:
        return self.kind == "anonymous"


def b64url(data: bytes) -> str:
    """Base64url without padding -- how every part of an assertion and a JWK is encoded."""
    return base64.urlsafe_b64encode(data).rstrip(b"=").decode("ascii")


def unb64url(text: str) -> bytes:
    return base64.urlsafe_b64decode(text + "=" * (-len(text) % 4))


_unb64 = unb64url     # the name this module used before the helpers became part of the contract


def key_id(public_raw: bytes) -> str:
    """The `kid` a public key is published and looked up under."""
    return hashlib.sha256(public_raw).hexdigest()[:16]


def jwk(public_raw: bytes) -> dict[str, str]:
    """One Ed25519 public key as a JWK -- the shape `/api/v1/identity/keys` serves and `PlatformKeys` reads."""
    return {"kty": "OKP", "crv": "Ed25519", "alg": "EdDSA", "use": "sig", "kid": key_id(public_raw),
            "x": b64url(public_raw)}


def verify_assertion(token: str, *, audience: str, keys: dict[str, bytes] | Iterable[dict[str, str]],
                     now: float | None = None, leeway: float = LEEWAY_SECONDS,
                     seen: set[str] | None = None) -> dict[str, Any]:
    """Check an `X-CSP-Assertion`; return its claims or raise `IdentityError`.

    `keys`: {kid: raw public key} or a JWKS `keys` list. `seen`: pass a set to refuse a replayed `jti`
    (keep it for `exp` seconds). Checks: format, `alg`, known `kid`, signature, `iss`, `aud`, `iat`/`exp`
    with `leeway`, and that `exp - iat` is not longer than the platform ever issues.
    """
    if not token or len(token) > MAX_TOKEN or token.count(".") != 2:
        raise IdentityError("沒有身分，或格式不對")
    if not isinstance(keys, dict):
        keys = {k["kid"]: _unb64(k["x"]) for k in keys if k.get("crv") == "Ed25519" and k.get("kid")}
    head_b64, body_b64, sig_b64 = token.split(".")
    try:
        header = json.loads(_unb64(head_b64))
        claims = json.loads(_unb64(body_b64))
        signature = _unb64(sig_b64)
    except (ValueError, UnicodeDecodeError) as exc:
        raise IdentityError("身分的格式不對") from exc
    if not isinstance(header, dict) or header.get("alg") != "EdDSA":
        raise IdentityError("簽章演算法不對")            # never "none", never anything else
    public = keys.get(header.get("kid", ""))
    if public is None:
        raise IdentityError("不認得簽章用的金鑰（平台可能換過金鑰：重新抓一次公鑰）")
    try:
        Ed25519PublicKey.from_public_bytes(public).verify(signature, f"{head_b64}.{body_b64}".encode("ascii"))
    except (InvalidSignature, ValueError) as exc:
        raise IdentityError("簽章不對") from exc
    if not isinstance(claims, dict) or claims.get("iss") != ISSUER:
        raise IdentityError("不是 CSP 發的")
    if claims.get("aud") != audience:
        raise IdentityError("這張身分是給別的服務的")
    now = time.time() if now is None else now
    iat, exp = claims.get("iat"), claims.get("exp")
    if not isinstance(iat, (int, float)) or not isinstance(exp, (int, float)):
        raise IdentityError("身分沒有時間")
    if exp - iat > LIFETIME_SECONDS + 1 or iat > now + leeway or exp < now - leeway:
        raise IdentityError("身分過期了")
    if seen is not None:
        jti = claims.get("jti")
        if not isinstance(jti, str) or jti in seen:
            raise IdentityError("這張身分已經用過了")
        seen.add(jti)
    if not isinstance(claims.get("sub"), str) or not claims["sub"]:
        raise IdentityError("身分沒有寫是誰")
    return claims


class PlatformKeys:
    """The platform's public keys (`/api/v1/identity/keys`), cached; refetched (at most once a minute) when an
    assertion names a key we do not have -- that is what a key rotation looks like from here."""

    def __init__(self, fetch=None) -> None:
        self._fetch = fetch or (lambda: _http.request("GET", "/identity/keys")["keys"])
        self._keys: dict[str, bytes] = {}
        self._fetched_at = 0.0
        self._lock = threading.Lock()

    def get(self, *, refresh: bool = False) -> dict[str, bytes]:
        with self._lock:
            stale = time.monotonic() - self._fetched_at > 60
            if not self._keys or (refresh and stale):
                try:
                    self._keys = {k["kid"]: _unb64(k["x"]) for k in self._fetch() if k.get("crv") == "Ed25519"}
                except Exception:     # local mode or the platform is down: nothing verifies, nothing passes
                    self._keys = self._keys or {}
                self._fetched_at = time.monotonic()
            return dict(self._keys)


class _Seen:
    """jti values seen in the last couple of minutes (an assertion is good for 60 s): replays are refused."""

    def __init__(self) -> None:
        self._seen: dict[str, float] = {}
        self._lock = threading.Lock()

    def check_and_add(self, jti: str) -> bool:
        now = time.monotonic()
        with self._lock:
            if len(self._seen) > 10000 or any(t < now for t in list(self._seen.values())[:50]):
                self._seen = {k: t for k, t in self._seen.items() if t >= now}
            if jti in self._seen:
                return False
            self._seen[jti] = now + LIFETIME_SECONDS + 2 * LEEWAY_SECONDS
            return True


_default_keys = PlatformKeys()
_seen = _Seen()


def _hostname(host_header: str) -> str:
    host = host_header.strip().lower()
    if host.startswith("["):
        return host[1:host.find("]")] if "]" in host else host
    return host.rsplit(":", 1)[0] if host.count(":") == 1 else host


def identify(headers: Mapping[str, str], client_host: str, *, auth: str | None = None,
             service_id: str | None = None, keys: PlatformKeys | None = None,
             now: float | None = None) -> Principal:
    """Who is behind this request -- or `Refused`. `headers`: lower-case names."""
    auth = auth or _env.auth_mode()
    audience = service_id if service_id is not None else _env.service_id()
    keys = keys or _default_keys
    token = headers.get(HEADER)
    forwarded = any(h in headers for h in FORWARD_HEADERS)
    if client_host not in LOOPBACK:
        raise Refused(403, "只接受本機的連線（服務要只綁 127.0.0.1，外面的人要經過門口）")
    if token:
        try:
            try:
                claims = verify_assertion(token, audience=audience, keys=keys.get(), now=now)
            except IdentityError as exc:
                if "不認得" not in str(exc):
                    raise
                claims = verify_assertion(token, audience=audience, keys=keys.get(refresh=True), now=now)
        except IdentityError as exc:
            raise Refused(401, f"身分不對：{exc}") from exc
        if not _seen.check_and_add(str(claims.get("jti"))):
            raise Refused(401, "這張身分已經用過了")
        kind = "owner" if claims.get("kind") == "owner" else "member"
        return Principal(kind, claims["sub"], tuple(claims.get("groups") or ()), via="gate", claims=claims)
    if forwarded:
        if auth == "platform":
            raise Refused(401, "經過門口卻沒有平台簽的身分")
        return Principal("anonymous", via="gate")      # `own`: the service's own login decides
    if _hostname(headers.get("host", "")) not in LOOPBACK:
        raise Refused(421, "Host 不是本機（可能是 DNS rebinding）")
    return Principal("owner", "local", via="local")

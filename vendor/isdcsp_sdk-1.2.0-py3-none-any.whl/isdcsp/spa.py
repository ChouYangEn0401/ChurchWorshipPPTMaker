"""A built front end and its API behind one address -- the front/back split, done safely (1.2, ADR 0037).

    from isdcsp.spa import Spa
    app = Spa("frontend/dist", api=api_app)     # /api/... -> the API app; everything else -> the built front end
    isdcsp.serve(app)                           # 127.0.0.1 only, behind isdcsp.Guard

The shape of StockLikenessClassifier (Vite + FastAPI) and of any React/Vue build:

- A path under `api_prefix` (default `/api/`) goes to `api` -- HTTP and WebSocket alike. Without an API it is 404.
- Anything else is a file of `dist`, or, for a path that is not a file (`/runs/12`), `index.html` -- the front end's
  own router takes it from there. A missing *file* (`/assets/app.9f3c.js`, anything with a suffix) is a 404, never
  `index.html`: a browser told that HTML is a script breaks in ways that are hard to see.
- **Only files inside `dist` are ever served.** The path is decoded once, then refused if it holds a NUL, a
  backslash, a drive letter, an absolute path or a `..` part, and the resolved file must still be under `dist`
  (symlinks included). The obvious version -- `dist / path` -- serves any file on the disk: `Path("dist") /
  "C:/Users/..."` *is* `C:/Users/...`, and `..%2F` arrives decoded as `../`.
- Caching that suits a build over a tunnel: hashed assets (under `immutable` prefixes, default `/assets/`) are cached
  for a year; `index.html` and the rest revalidate (`no-cache`) with an ETag, so a reload costs a 304, not a download.
- GET and HEAD only for files; files are streamed in 64 KB pieces (memory stays flat however large the build).

Security headers and who-is-asking are the layer around it (`isdcsp.Guard`, or `isdcsp.web.Site`).
"""

from __future__ import annotations

import hashlib
import mimetypes
from pathlib import Path, PurePosixPath
from typing import Any, Callable

CHUNK = 64 * 1024
_TYPES = {".js": "text/javascript", ".mjs": "text/javascript", ".css": "text/css", ".svg": "image/svg+xml",
          ".json": "application/json", ".wasm": "application/wasm", ".map": "application/json",
          ".webmanifest": "application/manifest+json", ".ico": "image/x-icon", ".woff2": "font/woff2"}


def resolve_inside(root: Path, url_path: str) -> Path | None:
    """The file `url_path` names inside `root`, or None if it names nothing there -- or anything outside it.

    `url_path` is the decoded request path (ASGI's `scope["path"]`). Refused outright: NUL, a backslash, a colon (a
    drive letter or an alternate data stream on Windows), a `..` part. Then the joined path is resolved and must
    still be inside `root`: that also catches a symlink pointing out."""
    if "\x00" in url_path or "\\" in url_path or ":" in url_path:
        return None
    parts = [p for p in PurePosixPath("/" + url_path.lstrip("/")).parts[1:] if p not in ("", ".")]
    if any(p == ".." for p in parts):
        return None
    base = root.resolve()
    candidate = base.joinpath(*parts).resolve() if parts else base
    if candidate != base and base not in candidate.parents:
        return None
    return candidate


class Spa:
    def __init__(self, dist: str | Path, *, api: Any = None, api_prefix: str = "/api/", index: str = "index.html",
                 immutable: tuple[str, ...] = ("/assets/",)) -> None:
        self.dist = Path(dist)
        self.api = api
        self.api_prefix = api_prefix if api_prefix.endswith("/") else api_prefix + "/"
        self.index = index
        self.immutable = immutable

    async def __call__(self, scope: dict, receive: Callable, send: Callable) -> None:
        kind = scope["type"]
        if kind == "lifespan":
            if self.api is not None:
                await self.api(scope, receive, send)
            else:
                await _lifespan(receive, send)
            return
        path = scope.get("path", "/")
        if path == self.api_prefix.rstrip("/") or path.startswith(self.api_prefix):
            if self.api is not None:
                await self.api(scope, receive, send)
            elif kind == "websocket":
                await send({"type": "websocket.close", "code": 1008})
            else:
                await _plain(send, 404, b'{"detail": "not found"}', "application/json")
            return
        if kind != "http":
            await send({"type": "websocket.close", "code": 1008})
            return
        method = scope.get("method", "GET").upper()
        if method not in ("GET", "HEAD"):
            await _plain(send, 405, "這裡只有網頁，不能送資料".encode("utf-8"), "text/plain; charset=utf-8",
                         extra=[(b"allow", b"GET, HEAD")])
            return
        target = resolve_inside(self.dist, path)
        if target is not None and target.is_file():
            await self._file(scope, send, target, immutable=path.startswith(self.immutable))
            return
        if PurePosixPath(path).suffix:        # a file that is not there (or not ours): never index.html for it
            await _plain(send, 404, "找不到這個檔案".encode("utf-8"), "text/plain; charset=utf-8")
            return
        index = self.dist / self.index
        if not index.is_file():
            await _plain(send, 503, "前端還沒建好：在 frontend/ 執行 npm run build".encode("utf-8"),
                         "text/plain; charset=utf-8")
            return
        await self._file(scope, send, index, immutable=False)

    async def _file(self, scope: dict, send: Callable, file: Path, *, immutable: bool) -> None:
        stat = file.stat()
        tag = '"' + hashlib.sha1(f"{stat.st_mtime_ns}-{stat.st_size}".encode()).hexdigest()[:20] + '"'
        headers = {k.decode("latin-1").lower(): v.decode("latin-1") for k, v in scope.get("headers", [])}
        content_type = _TYPES.get(file.suffix.lower()) or mimetypes.guess_type(file.name)[0] or "application/octet-stream"
        if content_type.startswith("text/") or content_type in ("application/json", "image/svg+xml"):
            content_type += "; charset=utf-8"
        cache = "public, max-age=31536000, immutable" if immutable else "no-cache"
        common = [(b"etag", tag.encode()), (b"cache-control", cache.encode()), (b"x-content-type-options", b"nosniff")]
        if headers.get("if-none-match") == tag:
            await send({"type": "http.response.start", "status": 304, "headers": common})
            await send({"type": "http.response.body", "body": b""})
            return
        await send({"type": "http.response.start", "status": 200,
                    "headers": [(b"content-type", content_type.encode()),
                                (b"content-length", str(stat.st_size).encode()), *common]})
        if scope.get("method", "GET").upper() == "HEAD":
            await send({"type": "http.response.body", "body": b""})
            return
        with open(file, "rb") as fh:
            while True:
                chunk = fh.read(CHUNK)
                more = len(chunk) == CHUNK
                await send({"type": "http.response.body", "body": chunk, "more_body": more})
                if not more:
                    break


async def _plain(send: Callable, status: int, body: bytes, content_type: str, *,
                 extra: list[tuple[bytes, bytes]] | None = None) -> None:
    await send({"type": "http.response.start", "status": status,
                "headers": [(b"content-type", content_type.encode()), (b"content-length", str(len(body)).encode()),
                            (b"x-content-type-options", b"nosniff"), (b"cache-control", b"no-store"),
                            *(extra or [])]})
    await send({"type": "http.response.body", "body": body})


async def _lifespan(receive: Callable, send: Callable) -> None:
    while True:
        message = await receive()
        if message["type"] == "lifespan.startup":
            await send({"type": "lifespan.startup.complete"})
        elif message["type"] == "lifespan.shutdown":
            await send({"type": "lifespan.shutdown.complete"})
            return


__all__ = ["CHUNK", "Spa", "resolve_inside"]

"""Child processes that can never outlive the program that started them.

On Windows every child is put in a Job Object with JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE: if the parent exits or
crashes, Windows kills the child and all of its descendants (cloudflared, a .bat and the python it launched...).
`kill_tree()` terminates the whole job. Elsewhere a new process group is used. Commands are always argument lists --
never a shell string.

Shared by the platform (`csp_platform.core.processes` imports `ManagedProcess`) and every service: a service's own
tunnel (`isdcsp.tunnel`) runs cloudflared through it, so a crashed service can never leave a cloudflared behind
still pointing at its port -- the copy PPTMaker had before used a plain Popen, and an orphaned one would have kept
exposing whatever started on that port next.
"""

from __future__ import annotations

import logging
import os
import signal
import subprocess
import sys
import threading
from pathlib import Path
from typing import IO, Sequence

log = logging.getLogger(__name__)

if sys.platform == "win32":
    import ctypes
    from ctypes import wintypes

    _kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)

    class _IoCounters(ctypes.Structure):
        _fields_ = [(name, ctypes.c_ulonglong) for name in (
            "ReadOperationCount", "WriteOperationCount", "OtherOperationCount",
            "ReadTransferCount", "WriteTransferCount", "OtherTransferCount")]

    class _BasicLimit(ctypes.Structure):
        _fields_ = [
            ("PerProcessUserTimeLimit", ctypes.c_int64),
            ("PerJobUserTimeLimit", ctypes.c_int64),
            ("LimitFlags", wintypes.DWORD),
            ("MinimumWorkingSetSize", ctypes.c_size_t),
            ("MaximumWorkingSetSize", ctypes.c_size_t),
            ("ActiveProcessLimit", wintypes.DWORD),
            ("Affinity", ctypes.c_size_t),
            ("PriorityClass", wintypes.DWORD),
            ("SchedulingClass", wintypes.DWORD),
        ]

    class _ExtendedLimit(ctypes.Structure):
        _fields_ = [
            ("BasicLimitInformation", _BasicLimit),
            ("IoInfo", _IoCounters),
            ("ProcessMemoryLimit", ctypes.c_size_t),
            ("JobMemoryLimit", ctypes.c_size_t),
            ("PeakProcessMemoryUsed", ctypes.c_size_t),
            ("PeakJobMemoryUsed", ctypes.c_size_t),
        ]

    _kernel32.CreateJobObjectW.argtypes = [ctypes.c_void_p, wintypes.LPCWSTR]
    _kernel32.CreateJobObjectW.restype = wintypes.HANDLE
    _kernel32.SetInformationJobObject.argtypes = [wintypes.HANDLE, ctypes.c_int, ctypes.c_void_p, wintypes.DWORD]
    _kernel32.SetInformationJobObject.restype = wintypes.BOOL
    _kernel32.AssignProcessToJobObject.argtypes = [wintypes.HANDLE, wintypes.HANDLE]
    _kernel32.AssignProcessToJobObject.restype = wintypes.BOOL
    _kernel32.TerminateJobObject.argtypes = [wintypes.HANDLE, wintypes.UINT]
    _kernel32.TerminateJobObject.restype = wintypes.BOOL
    _kernel32.CloseHandle.argtypes = [wintypes.HANDLE]
    _kernel32.CloseHandle.restype = wintypes.BOOL

    _ntdll = ctypes.WinDLL("ntdll")
    _ntdll.NtResumeProcess.argtypes = [wintypes.HANDLE]
    _ntdll.NtResumeProcess.restype = ctypes.c_long

    _JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE = 0x2000
    _JOB_OBJECT_EXTENDED_LIMIT_INFORMATION = 9
    _CREATE_SUSPENDED = 0x00000004

    class _Job:
        def __init__(self) -> None:
            self.handle = _kernel32.CreateJobObjectW(None, None)
            if not self.handle:
                raise OSError(ctypes.get_last_error(), "CreateJobObjectW failed")
            info = _ExtendedLimit()
            info.BasicLimitInformation.LimitFlags = _JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE
            if not _kernel32.SetInformationJobObject(self.handle, _JOB_OBJECT_EXTENDED_LIMIT_INFORMATION,
                                                     ctypes.byref(info), ctypes.sizeof(info)):
                err = ctypes.get_last_error()
                _kernel32.CloseHandle(self.handle)
                raise OSError(err, "SetInformationJobObject failed")

        def assign(self, process: subprocess.Popen) -> bool:
            return bool(_kernel32.AssignProcessToJobObject(self.handle, int(process._handle)))  # type: ignore[attr-defined]

        def terminate(self) -> None:
            if self.handle:
                _kernel32.TerminateJobObject(self.handle, 1)

        def close(self) -> None:
            handle, self.handle = self.handle, None  # never CloseHandle the same (possibly reused) value twice
            if handle:
                _kernel32.CloseHandle(handle)


class ManagedProcess:
    def __init__(self, process: subprocess.Popen, job: object | None) -> None:
        self.process = process
        self._job = job
        self._job_lock = threading.Lock()  # kill_tree/close are called from supervisor AND watchdog threads

    @classmethod
    def start(cls, args: Sequence[str], *, cwd: Path | None = None, env: dict[str, str] | None = None,
              stdout: int | IO | None = subprocess.DEVNULL, stderr: int | IO | None = subprocess.PIPE,
              text: bool = True) -> "ManagedProcess":
        if isinstance(args, (str, bytes)):
            raise TypeError("args must be a list, never a shell string")
        kwargs: dict = dict(cwd=str(cwd) if cwd else None, env=env, stdin=subprocess.DEVNULL, stdout=stdout,
                            stderr=stderr, shell=False, close_fds=True)
        if text:
            kwargs.update(text=True, encoding="utf-8", errors="replace", bufsize=1)
        job = None
        if sys.platform == "win32":
            # Start suspended, join the job, then resume: the child cannot spawn anything outside the job.
            kwargs["creationflags"] = subprocess.CREATE_NO_WINDOW | _CREATE_SUSPENDED
            job = _Job()
            try:
                process = subprocess.Popen(list(args), **kwargs)
            except BaseException:
                job.close()
                raise
            assigned = job.assign(process)
            error = ctypes.get_last_error() if not assigned else 0
            status = _ntdll.NtResumeProcess(int(process._handle)) if assigned else None  # type: ignore[attr-defined]
            if not assigned or status != 0:
                job.terminate()
                try:
                    process.kill()
                    process.wait(timeout=5)
                except (OSError, subprocess.TimeoutExpired):
                    pass
                job.close()
                detail = (f"AssignProcessToJobObject failed (winerror {error})" if not assigned
                          else f"NtResumeProcess failed (NTSTATUS 0x{status & 0xFFFFFFFF:08X})")
                raise OSError(error or 1, f"could not start the child inside a job object: {detail}")
        else:
            kwargs["start_new_session"] = True
            process = subprocess.Popen(list(args), **kwargs)
        return cls(process, job)

    @property
    def pid(self) -> int:
        return self.process.pid

    def alive(self) -> bool:
        return self.process.poll() is None

    def kill_tree(self, grace_seconds: float = 3.0) -> int | None:
        """Stop the whole tree. Returns the exit code.

        Windows children have no console (CREATE_NO_WINDOW), so console Ctrl events cannot reach them —
        and GenerateConsoleCtrlEvent could hit our own console group — so the job is simply terminated.
        """
        if self.alive() and sys.platform != "win32":
            try:
                os.killpg(self.process.pid, signal.SIGTERM)
                self.process.wait(timeout=grace_seconds)
            except (OSError, subprocess.TimeoutExpired):
                pass
        if sys.platform == "win32":
            with self._job_lock:
                if self._job is not None:
                    self._job.terminate()  # type: ignore[attr-defined]
        elif self.alive():
            try:
                os.killpg(self.process.pid, signal.SIGKILL)  # type: ignore[attr-defined]
            except OSError:
                pass
        if self.alive():
            self.process.kill()
        try:
            return self.process.wait(timeout=5)
        except subprocess.TimeoutExpired:
            return None
        finally:
            self.close()

    def close(self) -> None:
        with self._job_lock:
            job, self._job = self._job, None
        if job is not None:
            job.close()  # type: ignore[attr-defined]

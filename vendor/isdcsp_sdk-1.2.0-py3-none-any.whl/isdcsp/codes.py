"""One-time login codes (ADR 0010): six digits to the person's phone, a 128-bit nonce to the browser tab that asked.

Both halves are required, so a code someone read over a shoulder -- or out of a stolen Telegram account -- is
useless in another tab, another browser or another session.

Everything lives in memory on purpose: a restart must invalidate every pending login, and the code must never
reach a log line, an audit table or a database. Only digests are kept, and both halves are compared in constant
time.

Three layers; use the one you need:

    generate_code / looks_like_nonce              the pieces
    LoginCodeStore(clock, limits)                 one pending login plus the budgets that protect the phone the
                                                  codes go to -- the platform's own Telegram login is this store
    for_service(deliver=...)                      what a service calls: under CSP with `[uses] codes = "platform"`,
                                                  CSP sends the code to the owner's Telegram and the service only
                                                  ever holds the nonce; otherwise the service's own store, and its
                                                  own way of sending the code (`deliver`)

    codes = isdcsp.codes.for_service()
    started = codes.request(visitor_ip, context={"ua": user_agent})   # -> CodeStart(ok, nonce, expires_in, ...)
    ...                                                               # the page keeps `started.nonce`
    if codes.verify(form["nonce"], form["code"]): ...                 # True exactly once, for that tab only
"""

from __future__ import annotations

import hashlib
import re
import secrets
import sys
import threading
import time
from collections import defaultdict, deque
from dataclasses import dataclass
from typing import Any, Callable, Protocol

from isdcsp import _env, _http
from isdcsp.net import LOCAL_IP, ban_key
from isdcsp.tokens import new_token, same
from isdcsp.totp import only_digits

CODE_DIGITS = 6
NONCE_BYTES = 16  # 128 bits -> 22 url-safe characters, shorter than a session token
MODES = ("none", "own", "platform")       # `[uses] codes` in service.isdcsp.toml
_NONCE_RE = re.compile(r"^[A-Za-z0-9_-]{20,200}$")

__all__ = ["CODE_DIGITS", "MODES", "NONCE_BYTES", "CodeLimits", "CodeRequest", "CodeStart", "LocalCodes",
           "LoginCodeStore", "PlatformCodes", "declared_mode", "for_service", "generate_code", "looks_like_nonce",
           "only_digits"]


def generate_code(digits: int = CODE_DIGITS) -> str:
    """A uniformly random decimal code, leading zeros kept (`secrets`, never `random`)."""
    return f"{secrets.randbelow(10 ** digits):0{digits}d}"


def looks_like_nonce(value: str | None) -> bool:
    """Shape check before a nonce is echoed back into a page (templates escape it either way)."""
    return bool(value) and bool(_NONCE_RE.match(value))


def _digest(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


# ---------------------------------------------------------------------------- limits
class Limits(Protocol):
    """What `LoginCodeStore` reads, every time it needs it (so a platform can hand in live settings)."""

    seconds: int
    attempts: int
    per_ip: int
    total: int
    window_minutes: int
    alert_after: int


@dataclass(frozen=True)
class CodeLimits:
    seconds: int = 90         # how long a code lives
    attempts: int = 3         # wrong codes from the tab that holds the nonce before the pending login dies
    per_ip: int = 5           # codes one network (`ban_key`) may ask for per window
    total: int = 10           # codes everybody together may ask for per window -- this machine is exempt
    window_minutes: int = 10
    alert_after: int = 3      # refusals in a window before the owner is told (once per window)


@dataclass
class _Pending:
    """One pending login. Holds digests only -- never the code or the nonce themselves."""

    id: str
    code_digest: str
    nonce_digest: str
    created_at: float
    expires_at: float
    attempts: int = 0


@dataclass(frozen=True)
class CodeRequest:
    """What `LoginCodeStore.request` decided. `code` and `nonce` are set only when `ok`."""

    ok: bool
    pending_id: str = ""
    code: str = ""
    nonce: str = ""
    expires_in: int = 0
    replaced: bool = False      # an older pending login was invalidated by this one
    alert_owner: bool = False   # enough refusals piled up to tell the owner once
    refusals: int = 0           # refusals in this window, so one audit line can carry the tally
    note_refusal: bool = False  # write the audit line for this refusal (at most one per window)

    def __repr__(self) -> str:  # the code must not be able to reach a log line
        return (f"CodeRequest(ok={self.ok}, id={self.pending_id!r}, expires_in={self.expires_in}, "
                f"replaced={self.replaced}, alert_owner={self.alert_owner}, refusals={self.refusals})")


class LoginCodeStore:
    """The single pending login, plus the rate limits that protect the phone the codes are sent to."""

    def __init__(self, clock: Callable[[], float] = time.time, limits: Limits | None = None) -> None:
        self._now = clock
        self.limits = limits or CodeLimits()
        self._lock = threading.Lock()
        self._pending: _Pending | None = None
        self._per_ip: dict[str, deque[float]] = defaultdict(deque)
        self._requests: deque[float] = deque()
        self._refusals: deque[float] = deque()
        self._alert_muted_until = 0.0
        self._audit_muted_until = 0.0

    @property
    def ttl_seconds(self) -> int:
        return int(self.limits.seconds)

    @property
    def window_seconds(self) -> float:
        return self.limits.window_minutes * 60

    def request(self, ip: str) -> CodeRequest:
        """Create a pending login, replacing any live one (the newest code is the only valid one).

        Replacing rather than refusing keeps the *granted* answer identical whether or not a pending login exists,
        so a granted request never says "somebody is logging in right now". A refusal is distinguishable (it has to
        be: it is a refusal), and because the global budget is shared it does tell a stranger that codes were handed
        out recently.

        Two exemptions mirror the platform's IP guard, which never counts local requests at all:

        - the per-IP budget is keyed on `ban_key`, so one IPv6 host cannot buy a fresh budget per privacy address
          inside its own /64 and empty the global one by itself;
        - a request from this machine (`LOCAL_IP`) is never refused by the *global* budget, so a stranger on the
          tunnel cannot take the one-tap login away from the owner at the keyboard. Local keeps its own per-IP
          budget, so a local process still cannot flood the owner's phone.
        """
        now = self._now()
        horizon = now - self.window_seconds
        local = ip == LOCAL_IP
        with self._lock:
            _trim(self._requests, horizon)
            _trim(self._refusals, horizon)
            per_ip = self._per_ip[ban_key(ip)]
            _trim(per_ip, horizon)
            if len(per_ip) >= self.limits.per_ip or (not local and len(self._requests) >= self.limits.total):
                self._refusals.append(now)
                alert = len(self._refusals) >= self.limits.alert_after and now >= self._alert_muted_until
                if alert:
                    # One "someone keeps asking" message per window, never one per attempt.
                    self._alert_muted_until = now + self.window_seconds
                note = now >= self._audit_muted_until
                if note:
                    # One audit line per window too, carrying the tally: refusals are cheap enough to ask for
                    # hundreds of times a minute, and a row each would grow an audit table without bound.
                    self._audit_muted_until = now + self.window_seconds
                return CodeRequest(ok=False, alert_owner=alert, refusals=len(self._refusals), note_refusal=note)
            per_ip.append(now)
            self._requests.append(now)
            code = generate_code()
            nonce = new_token(NONCE_BYTES)
            replaced = self._pending is not None and self._pending.expires_at > now
            self._pending = _Pending(id=secrets.token_hex(8), code_digest=_digest(code), nonce_digest=_digest(nonce),
                                     created_at=now, expires_at=now + self.ttl_seconds)
            return CodeRequest(ok=True, pending_id=self._pending.id, code=code, nonce=nonce,
                               expires_in=self.ttl_seconds, replaced=replaced)

    def verify(self, nonce: str | None, code: str | None) -> bool:
        """True exactly once, and only for the tab that asked for this code.

        A wrong code from the tab that holds the nonce burns one of `limits.attempts`; the pending login dies when
        they run out. A submission **without** that nonce burns nothing: it cannot become a login however many
        times it is repeated, so counting it would only hand a stranger a way to kill a login the owner is in the
        middle of. (The caller still counts it as a failed login against the sender's IP.)

        Both digests are computed before the pending login is even looked at, so "wrong code" and "no pending login
        at all" do the same work.
        """
        now = self._now()
        digits = only_digits(code)
        code_digest, nonce_digest = _digest(digits), _digest(nonce or "")
        with self._lock:
            pending = self._pending
            if pending is None:
                return False
            if pending.expires_at <= now:
                self._pending = None
                return False
            nonce_ok = bool(nonce) and same(nonce_digest, pending.nonce_digest)
            code_ok = len(digits) == CODE_DIGITS and same(code_digest, pending.code_digest)
            if code_ok and nonce_ok:
                self._pending = None  # single use
                return True
            if not nonce_ok:  # not the tab that asked: nothing of the owner's is spent
                return False
            pending.attempts += 1
            if pending.attempts >= self.limits.attempts:
                self._pending = None
            return False

    def discard(self) -> None:
        """Forget the pending login (another factor finished the login, or the person logged out)."""
        with self._lock:
            self._pending = None

    def prune(self) -> None:
        """Drop empty per-IP windows and an expired pending login (a maintenance job may call this)."""
        now = self._now()
        horizon = now - self.window_seconds
        with self._lock:
            for ip in list(self._per_ip):
                _trim(self._per_ip[ip], horizon)
                if not self._per_ip[ip]:
                    del self._per_ip[ip]
            _trim(self._requests, horizon)
            _trim(self._refusals, horizon)
            if self._pending is not None and self._pending.expires_at <= now:
                self._pending = None


def _trim(window: deque[float], horizon: float) -> None:
    while window and window[0] < horizon:
        window.popleft()


# ---------------------------------------------------------------------------- what a service uses
@dataclass(frozen=True)
class CodeStart:
    """The answer to "send a code" as a service sees it. Never carries the code: that goes to the phone only."""

    ok: bool
    nonce: str = ""
    expires_in: int = 0
    replaced: bool = False
    refused: bool = False       # a budget said no (try again later), as opposed to "could not send"
    alert_owner: bool = False   # local mode: enough refusals that the owner should hear about it
    message: str = ""

    def __repr__(self) -> str:
        return f"CodeStart(ok={self.ok}, expires_in={self.expires_in}, refused={self.refused})"


Deliver = Callable[[str, int, dict], Any]     # (code, expires_in, context) -> falsy only when it could not send


class LocalCodes:
    """The service's own codes: its own `LoginCodeStore`, and its own way of getting the code to the person.

    `deliver(code, expires_in, context)` is the service's channel (LINE Bot: its Telegram bot). Without one the code
    goes out with `isdcsp.notify` -- printed on this machine's console when the service runs alone, the owner's
    Telegram (as plain text) when CSP runs it and it declared `[uses] notify = true`.
    """

    def __init__(self, deliver: Deliver | None = None, *, limits: Limits | None = None,
                 clock: Callable[[], float] = time.time, label: str = "") -> None:
        self.store = LoginCodeStore(clock, limits)
        self.deliver = deliver or self._notify
        self.label = label

    def _notify(self, code: str, expires_in: int, context: dict) -> bool:
        from isdcsp.tools import notify     # here: tools imports nothing of ours, but keep codes light to import
        where = " ".join(str(context.get(k)) for k in ("where", "ua") if context.get(k))
        text = (f"🔢 {self.label or 'isdcsp'} 的登入碼：{code}（{expires_in} 秒內有效，只能用一次）"
                + (f"\n{where}" if where else "") + "\n不是你剛剛按的登入？別輸入這組數字。")
        if not _env.in_platform():
            print(f"[isdcsp codes] {text}", file=sys.stderr, flush=True)
            return True
        return notify(text)

    def request(self, ip: str, *, context: dict | None = None) -> CodeStart:
        result = self.store.request(ip)
        if not result.ok:
            return CodeStart(False, refused=True, alert_owner=result.alert_owner, message="剛剛要太多次了，請過幾分鐘再試")
        try:
            sent = self.deliver(result.code, result.expires_in, dict(context or {}))
        except Exception as exc:          # a broken channel must not leave a live code nobody received
            self.store.discard()
            return CodeStart(False, message=f"登入碼送不出去：{exc}")
        if sent is False:
            self.store.discard()
            return CodeStart(False, message="登入碼送不出去")
        return CodeStart(True, nonce=result.nonce, expires_in=result.expires_in, replaced=result.replaced)

    def verify(self, nonce: str | None, code: str | None) -> bool:
        return self.store.verify(nonce, code)

    def discard(self) -> None:
        self.store.discard()


class PlatformCodes:
    """CSP sends the code to the owner's Telegram (`[uses] codes = "platform"`, approved): the service asks for one
    and gets only the nonce; the code is on the phone and nowhere else. CSP keeps one pending login per service and
    its own budgets per service, so one service can neither flood the owner's phone nor touch CSP's own login."""

    def request(self, ip: str, *, context: dict | None = None) -> CodeStart:
        context = context or {}
        try:
            data = _http.request("POST", "/identity/codes", {"ip": ip, "ua": str(context.get("ua", ""))[:300]})
        except _http.PlatformError as exc:
            return CodeStart(False, refused=exc.status == 429, message=str(exc))
        return CodeStart(True, nonce=str(data.get("nonce", "")), expires_in=int(data.get("expires_in", 0)),
                         replaced=bool(data.get("replaced")))

    def verify(self, nonce: str | None, code: str | None) -> bool:
        if not looks_like_nonce(nonce):
            return False
        try:
            return bool(_http.request("POST", "/identity/codes/verify",
                                      {"nonce": nonce, "code": only_digits(code)}).get("ok"))
        except _http.PlatformError:
            return False

    def discard(self) -> None:
        """Nothing to do here: CSP drops the pending login when it is used or expires."""


def declared_mode() -> str:
    """`[uses] codes` in this service's manifest: "platform", "own", or "none" when it says nothing."""
    value = _env.manifest().get("uses", {}).get("codes", "none")
    return value if value in MODES else "none"


_services: dict[str, LocalCodes | PlatformCodes] = {}
_services_lock = threading.Lock()


def for_service(*, deliver: Deliver | None = None, mode: str | None = None,
                limits: Limits | None = None) -> LocalCodes | PlatformCodes:
    """The login codes this service should use (the same object every call).

    - `[uses] codes = "platform"` and started by CSP: CSP's (`PlatformCodes`).
    - Anything else: the service's own (`LocalCodes`) with `deliver` (or `isdcsp.notify`). So one program runs with
      the platform and without it, unchanged.
    """
    chosen = mode or declared_mode()
    if chosen not in MODES:
        raise ValueError(f"[uses] codes 只能是 {', '.join(MODES)}")
    key = "platform" if chosen == "platform" and _env.in_platform() else "own"
    with _services_lock:
        found = _services.get(key)
        if found is None:
            if key == "platform":
                found = PlatformCodes()
            else:
                service = _env.manifest().get("service", {})
                found = LocalCodes(deliver, limits=limits,
                                   label=str(service.get("name") or service.get("id") or _env.service_id()))
            _services[key] = found
        elif deliver is not None and isinstance(found, LocalCodes):
            found.deliver = deliver        # a later call that names the channel wins
        return found

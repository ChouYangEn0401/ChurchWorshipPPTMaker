"""Authenticator codes (Google Authenticator and the like: RFC 6238 TOTP) -- the one implementation.

Three layers; use the one you need:

    code_at / matching_counter / new_secret / provisioning_uri   the arithmetic (standard library only)
    Authenticator(store)                                         setup -> confirm -> verify, with replay
                                                                 protection and a lockout; *where* the secret
                                                                 and the counters live is handed in (`TotpStore`)
    for_service()                                                what a service calls: under CSP with
                                                                 `[uses] totp = "platform"`, the platform's
                                                                 authenticator (one entry on the owner's phone);
                                                                 otherwise the service's own, in data/secrets/

    auth = isdcsp.totp.for_service()
    if auth.configured and auth.verify(form["code"]):
        ...                                    # the person holds the phone

The platform's own authenticator (`csp_platform.kernel.totp`) is this `Authenticator` with the platform's
encrypted secrets store plugged in, so these rules are the same everywhere -- there is one copy of them:

- A new secret is *pending* until one correct code confirms it: a half-finished setup never locks anyone out and
  never replaces a working secret.
- `verify`: +-1 step of clock drift; every code counter works once (a code read over a shoulder is spent);
  `MAX_FAILURES` wrong codes in a row lock verification for `LOCKOUT_SECONDS`.
- `counts=False`: a wrong code does not wear down that lock -- for a stranger's guess before any other factor
  passed, which the caller's own throttle bounds; otherwise anybody could lock the owner out over and over.
"""

from __future__ import annotations

import base64
import hashlib
import hmac
import json
import secrets as _random
import struct
import threading
import time
from pathlib import Path
from typing import Callable, Protocol
from urllib.parse import quote

from isdcsp import _env, _files, _http

STEP = 30
DIGITS = 6
DRIFT_STEPS = 1
MAX_FAILURES = 5
LOCKOUT_SECONDS = 15 * 60

# What an authenticator keeps in its store. Secrets and plain values are asked for separately, so a store can
# encrypt the first kind (the platform does) and keep the second wherever is cheapest.
SECRET, PENDING = "secret", "pending"
LAST_COUNTER, FAILURES, LOCKED_UNTIL = "last_counter", "failures", "locked_until"

MODES = ("none", "own", "platform")       # `[uses] totp` in service.isdcsp.toml


class TotpError(ValueError):
    """Not set up, locked, or a setup step out of order. The message is written for a person."""


# ---------------------------------------------------------------------------- the arithmetic
def new_secret() -> str:
    """160 random bits in base32 without padding -- what an authenticator app's "enter a setup key" field takes."""
    return base64.b32encode(_random.token_bytes(20)).decode("ascii").rstrip("=")


def _key(secret: str) -> bytes:
    clean = secret.replace(" ", "").upper()
    return base64.b32decode(clean + "=" * (-len(clean) % 8))


def code_at(secret: str, counter: int, *, digits: int = DIGITS) -> str:
    """HOTP(secret, counter): RFC 4226 dynamic truncation over HMAC-SHA1 (what Google Authenticator uses)."""
    digest = hmac.new(_key(secret), struct.pack(">Q", counter), hashlib.sha1).digest()
    offset = digest[-1] & 0x0F
    value = struct.unpack(">I", digest[offset:offset + 4])[0] & 0x7FFFFFFF
    return str(value % (10 ** digits)).zfill(digits)


def counter_at(now: float) -> int:
    """The 30-second step `now` falls in: `code_at(secret, counter_at(time.time()))` is the code on the phone."""
    return int(now // STEP)


def matching_counter(secret: str, code: str, now: float, *, drift: int = DRIFT_STEPS) -> int | None:
    """The counter whose code `code` is, within +-`drift` steps of `now`; None otherwise.

    Exactly `DIGITS` digits or nothing: strip spaces before calling (`only_digits`) -- a typed "123 456" is fine,
    but deciding that is the caller's job, not a side effect here.
    """
    if not (isinstance(code, str) and code.isdigit() and len(code) == DIGITS):
        return None
    current = counter_at(now)
    for counter in range(current - drift, current + drift + 1):
        if hmac.compare_digest(code_at(secret, counter), code):
            return counter
    return None


def only_digits(value: str | None, limit: int = 32) -> str:
    """Keypads, autofill and people add spaces or dashes; a code is digits only."""
    return "".join(ch for ch in (value or "")[:limit] if ch.isdigit())


def provisioning_uri(secret: str, account: str = "owner", *, issuer: str = "isdcsp") -> str:
    """The `otpauth://` link a setup QR code carries; the app lists it as "<issuer>:<account>"."""
    label = quote(f"{issuer}:{account}")
    return (f"otpauth://totp/{label}?secret={secret}&issuer={quote(issuer)}&algorithm=SHA1"
            f"&digits={DIGITS}&period={STEP}")


def qr_svg(text: str) -> str | None:
    """A QR code for `text` as SVG markup when `segno` or `qrcode` is installed, else None (then show the secret to
    type in by hand). Neither is a dependency of the SDK: a project that already has one gets QR codes for free."""
    try:
        import segno  # type: ignore[import-not-found]
        return segno.make(text, error="m").svg_inline(scale=4)
    except ImportError:
        pass
    except Exception:            # a broken optional package must not break a login page
        return None
    try:
        import qrcode  # type: ignore[import-not-found]
        import qrcode.image.svg  # type: ignore[import-not-found]
        image = qrcode.make(text, image_factory=qrcode.image.svg.SvgPathImage)
        svg = image.to_string(encoding="unicode")
        return svg if isinstance(svg, str) else svg.decode("utf-8")
    except Exception:
        return None


# ---------------------------------------------------------------------------- where the state lives
class TotpStore(Protocol):
    """An authenticator's storage. `set_values` takes several at once so a file store writes once per answer."""

    def get_secret(self, name: str) -> str | None: ...

    def set_secret(self, name: str, value: str) -> None: ...

    def delete_secret(self, name: str) -> None: ...

    def get_value(self, name: str) -> str | None: ...

    def set_values(self, values: dict[str, str]) -> None: ...


class FileStore:
    """A small JSON file in a folder only the current user can read (`<project>/data/secrets/totp.json`).

    The secret is stored as it is: the folder's ACL is what protects it -- the same protection the platform gives
    its own master key -- and every write replaces the whole file atomically, so a crash never leaves half of one.
    One process per service (what `isdcsp.serve` runs): two processes sharing the file would share the lockout
    but could race on the replay check.
    """

    def __init__(self, path: Path) -> None:
        self.path = Path(path)
        self._lock = threading.Lock()

    def _load(self) -> dict[str, str]:
        try:
            data = json.loads(self.path.read_text(encoding="utf-8"))
        except FileNotFoundError:
            return {}
        except (OSError, ValueError) as exc:
            # Fail closed: a damaged file must not read as "not set up" and quietly drop a factor.
            raise TotpError(f"驗證器的設定檔讀不了：{self.path}（{exc}）") from exc
        return {str(k): str(v) for k, v in data.items()} if isinstance(data, dict) else {}

    def _save(self, data: dict[str, str]) -> None:
        _files.private_dir(self.path.parent)
        _files.atomic_write_bytes(self.path, json.dumps(data, ensure_ascii=False, indent=1).encode("utf-8"))

    def get_secret(self, name: str) -> str | None:
        with self._lock:
            return self._load().get(name)

    def set_secret(self, name: str, value: str) -> None:
        self.set_values({name: value})

    def delete_secret(self, name: str) -> None:
        with self._lock:
            data = self._load()
            if data.pop(name, None) is not None:
                self._save(data)

    def get_value(self, name: str) -> str | None:
        with self._lock:
            return self._load().get(name)

    def set_values(self, values: dict[str, str]) -> None:
        with self._lock:
            data = self._load()
            data.update({k: str(v) for k, v in values.items()})
            self._save(data)


def _int(value: str | None, default: int) -> int:
    try:
        return int(value) if value not in (None, "") else default
    except ValueError:
        return default


def _float(value: str | None) -> float:
    try:
        return float(value) if value not in (None, "") else 0.0
    except ValueError:
        return 0.0


# ---------------------------------------------------------------------------- the rules
class Authenticator:
    """setup -> confirm -> verify for one secret, with replay protection and a lockout (the rules above).

    Subclasses change the wording (the class attributes) and the issuer; the platform's does exactly that.
    """

    issuer = "isdcsp"
    NOT_CONFIGURED = "驗證器還沒設定"
    NO_PENDING = "沒有進行中的設定：先重新設定一次"
    WRONG_SETUP_CODE = "驗證碼不對（看一下手機上新加的那一組）"
    LOCKED = "驗證碼錯太多次，先鎖 15 分鐘"

    def __init__(self, store: TotpStore, *, clock: Callable[[], float] = time.time, issuer: str | None = None) -> None:
        self.store = store
        self._now = clock
        if issuer:
            self.issuer = issuer
        self._lock = threading.Lock()   # two requests carrying the same code must not both pass the replay check

    @property
    def configured(self) -> bool:
        return self.store.get_secret(SECRET) is not None

    def status(self) -> dict:
        locked = self._locked_until()
        return {"configured": self.configured, "pending": self.store.get_secret(PENDING) is not None,
                "locked_until": locked if locked > self._now() else None}

    def begin_setup(self, account: str = "owner") -> dict:
        """A new *pending* secret and the otpauth URI to scan; the working secret (if any) keeps working."""
        secret = new_secret()
        self.store.set_secret(PENDING, secret)
        return {"secret": secret, "uri": provisioning_uri(secret, account, issuer=self.issuer),
                "replaces_existing": self.configured}

    def confirm_setup(self, code: str) -> None:
        """Activate the pending secret -- only after one correct code from it."""
        pending = self.store.get_secret(PENDING)
        if pending is None:
            raise TotpError(self.NO_PENDING)
        counter = matching_counter(pending, code, self._now())
        if counter is None:
            raise TotpError(self.WRONG_SETUP_CODE)
        self.store.set_secret(SECRET, pending)
        self.store.delete_secret(PENDING)
        self.store.set_values({LAST_COUNTER: str(counter), FAILURES: "0"})

    def verify(self, code: str, *, counts: bool = True) -> bool:
        """True once per correct code. Raises `TotpError` when not set up or locked.

        `counts=False`: a wrong code does not wear down the lock (see the module docstring)."""
        secret = self.store.get_secret(SECRET)
        if secret is None:
            raise TotpError(self.NOT_CONFIGURED)
        with self._lock:
            now = self._now()
            if self._locked_until() > now:
                raise TotpError(self.LOCKED)
            counter = matching_counter(secret, code, now)
            last = _int(self.store.get_value(LAST_COUNTER), -1)
            if counter is None or counter <= last:
                if not counts:
                    return False
                failures = _int(self.store.get_value(FAILURES), 0) + 1
                if failures >= MAX_FAILURES:
                    self.store.set_values({LOCKED_UNTIL: str(now + LOCKOUT_SECONDS), FAILURES: "0"})
                else:
                    self.store.set_values({FAILURES: str(failures)})
                return False
            self.store.set_values({LAST_COUNTER: str(counter), FAILURES: "0"})
            return True

    def _locked_until(self) -> float:
        return _float(self.store.get_value(LOCKED_UNTIL))


# ---------------------------------------------------------------------------- what a service uses
class PlatformTotp:
    """The platform's authenticator, asked over the Control API (`[uses] totp = "platform"`, approved).

    The owner keeps one "ISD-CSP" entry on the phone for CSP and for every service that asks for this. The service
    never sees the secret, and wrong codes it sends count against *its own* budget on the platform -- a login page
    being guessed at through one service never locks the owner's own sign-in.
    """

    SETUP_ELSEWHERE = "這個服務用的是 CSP 的驗證器：要在 CSP 那台電腦上設定（csp totp setup）"
    # A login page asks "is it set up?" on every visit; the answer changes about never, so ask CSP at most this often.
    CACHE_SECONDS = 30

    def __init__(self) -> None:
        self._known: tuple[float, bool] | None = None

    @property
    def configured(self) -> bool:
        if self._known is not None and time.monotonic() - self._known[0] < self.CACHE_SECONDS:
            return self._known[1]
        try:
            value = bool(_http.request("GET", "/identity/totp").get("configured"))
        except _http.PlatformError:
            value = False
        self._known = (time.monotonic(), value)
        return value

    def status(self) -> dict:
        return {"configured": self.configured, "pending": False, "locked_until": None, "platform": True}

    def begin_setup(self, account: str = "owner") -> dict:
        raise TotpError(self.SETUP_ELSEWHERE)

    def confirm_setup(self, code: str) -> None:
        raise TotpError(self.SETUP_ELSEWHERE)

    def verify(self, code: str, *, counts: bool = True) -> bool:
        """`counts` is accepted for the same signature as `Authenticator.verify`; the platform never lets a service
        wear down the owner's lock, so it does not send it."""
        try:
            return bool(_http.request("POST", "/identity/totp/verify", {"code": code}).get("ok"))
        except _http.PlatformError as exc:
            raise TotpError(str(exc) or "問不到平台的驗證器") from exc


def declared_mode() -> str:
    """`[uses] totp` in this service's manifest: "platform", "own", or "none" when it says nothing."""
    value = _env.manifest().get("uses", {}).get("totp", "none")
    return value if value in MODES else "none"


_services: dict[tuple[str, str], Authenticator | PlatformTotp] = {}
_services_lock = threading.Lock()


def for_service(*, mode: str | None = None, path: Path | None = None) -> Authenticator | PlatformTotp:
    """The authenticator this service should use (the same object every call).

    - `[uses] totp = "platform"` and started by CSP: the platform's (`PlatformTotp`).
    - Anything else -- `"own"`, nothing declared, or `"platform"` while the service runs on its own -- the service's
      own `Authenticator`, its secret in `<project>/data/secrets/totp.json`. So one program runs with the platform
      and without it, unchanged: under CSP it is handed the platform's, on its own it uses its own.
    """
    chosen = mode or declared_mode()
    if chosen not in MODES:
        raise ValueError(f"[uses] totp 只能是 {', '.join(MODES)}")
    use_platform = chosen == "platform" and _env.in_platform()
    file = Path(path) if path else None
    key = ("platform", "") if use_platform else ("own", str(file or ""))
    with _services_lock:
        found = _services.get(key)
        if found is None:
            if use_platform:
                found = PlatformTotp()
            else:
                from isdcsp.tools import data_dir   # here, not at import: data_dir creates folders
                where = file or data_dir("secrets") / "totp.json"
                found = Authenticator(FileStore(where), issuer=_issuer())
            _services[key] = found
        return found


def _issuer() -> str:
    service = _env.manifest().get("service", {})
    return str(service.get("name") or service.get("id") or _env.service_id() or "isdcsp")

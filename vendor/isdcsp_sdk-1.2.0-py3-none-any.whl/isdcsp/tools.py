"""What a service asks the platform for, with a local fallback (BLUEPRINT §4.3).

- `notify(text)`: a Telegram message to the owner through CSP (needs `[uses] notify = true`). Local mode: printed.
- `secret(name)`: a secret the service declared in `[uses] secrets` (CSP puts it in the environment at start;
  asked from the platform if not). Never logged, never in argv.
- `run(argv)`: run a program -- a list of arguments only, never a shell string.
- `data_dir()`: the service's own data folder, inside its project folder.
"""

from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path
from typing import Any, Sequence

from isdcsp import _env, _http


def notify(text: str, *, silent: bool = False) -> bool:
    """True when the platform queued it; False in local mode (printed instead) or when it refused."""
    text = str(text)[:3000]
    if not _env.in_platform():
        print(f"[isdcsp notify] {text}", file=sys.stderr, flush=True)
        return False
    try:
        _http.request("POST", "/notifications", {"text": text, "silent": silent})
        return True
    except _http.PlatformError as exc:
        print(f"[isdcsp notify] 平台沒有收：{exc}", file=sys.stderr, flush=True)
        return False


def secret(name: str) -> str | None:
    value = os.environ.get(name)
    if value:
        return value
    if not _env.in_platform():
        return None
    try:
        return _http.request("GET", f"/secrets/{name}")["value"]
    except _http.PlatformError:
        return None


def run(argv: Sequence[str], **kwargs: Any) -> subprocess.CompletedProcess:
    """`subprocess.run` that refuses shell strings: one quote in a parameter must never become a second command."""
    if isinstance(argv, (str, bytes)):
        raise TypeError("isdcsp.run 只收字串陣列，不收一整行指令")
    if kwargs.pop("shell", False):
        raise ValueError("isdcsp.run 不開 shell")
    return subprocess.run([str(a) for a in argv], shell=False, **kwargs)


def data_dir(*parts: str) -> Path:
    """`<project>/data[/parts]`, created on first use. Refuses paths that climb out of the project's data folder."""
    base = (_env.project_root() / "data").resolve()
    target = base.joinpath(*parts).resolve()
    if target != base and base not in target.parents:
        raise ValueError("data_dir 只能指向專案自己的 data 資料夾裡面")
    target.mkdir(parents=True, exist_ok=True)
    return target

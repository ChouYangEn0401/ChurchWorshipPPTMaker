"""Where am I running? Inside the platform (CSP started me) or on my own (local mode).

CSP injects, when it starts a service (BLUEPRINT §4.2): `CSP_PORT`, `CSP_SERVICE_ID`, `CSP_API`,
`CSP_SERVICE_TOKEN` and the secrets the service declared. Without them the SDK runs in local mode:
the port comes from the manifest, notifications are printed, identity treats this machine as the owner.
"""

from __future__ import annotations

import os
import tomllib
from functools import lru_cache
from pathlib import Path
from typing import Any

MANIFEST = "service.isdcsp.toml"
DEFAULT_PORT = 8800


def in_platform() -> bool:
    return bool(os.environ.get("CSP_API") and os.environ.get("CSP_SERVICE_TOKEN"))


def api_url() -> str:
    return os.environ.get("CSP_API", "").rstrip("/")


def service_token() -> str:
    return os.environ.get("CSP_SERVICE_TOKEN", "")


def project_root(start: Path | None = None) -> Path:
    """The folder holding `service.isdcsp.toml` (searching upwards from `start` or the working directory)."""
    here = (start or Path.cwd()).resolve()
    for folder in (here, *here.parents):
        if (folder / MANIFEST).is_file():
            return folder
    return here


@lru_cache(maxsize=4)
def _manifest(root: str) -> dict[str, Any]:
    path = Path(root) / MANIFEST
    if not path.is_file():
        return {}
    try:
        with open(path, "rb") as fh:
            return tomllib.load(fh)
    except (OSError, tomllib.TOMLDecodeError):
        return {}


def manifest() -> dict[str, Any]:
    return _manifest(str(project_root()))


def service_id() -> str:
    return os.environ.get("CSP_SERVICE_ID") or str(manifest().get("service", {}).get("id", ""))


def auth_mode() -> str:
    """`[access] auth` of this service: platform | own | none (no [access] = local only = none)."""
    return str(manifest().get("access", {}).get("auth", "none"))


def port() -> int:
    """The port to listen on: CSP's lease when the platform started us, else the manifest's, else 8800."""
    value = os.environ.get("CSP_PORT")
    if value and value.isdigit():
        return int(value)
    declared = manifest().get("run", {}).get("port")
    return int(declared) if isinstance(declared, int) else DEFAULT_PORT
